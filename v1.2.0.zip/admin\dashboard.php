<?php
/**
 * Application: E-Arsip Madrasah Digital
 * Developer: Tumenggung Danang Triharto
 * URL: https://admin.mtssmaarif02kotagajah.my.id
 * All Rights Reserved © 2026
 */
/**
 * ============================================================
 * DASHBOARD — E-Arsip Digital MTs Ma'arif 02 Kotagajah
 * ============================================================
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/index.php'); exit; }
require_once __DIR__ . '/../config/koneksi.php';

requireLogin();

// ============================================================
// QUERY STATISTIK
// ============================================================
$totalArsip = @$koneksi->query("SELECT COUNT(*) as total FROM arsip")->fetch_assoc()['total'] ?? 0;
$totalKategori = @$koneksi->query("SELECT COUNT(*) as total FROM kategori")->fetch_assoc()['total'] ?? 0;

$bulanIni = date('Y-m');
$arsipBulanIni = @$koneksi->query("SELECT COUNT(*) as total FROM arsip WHERE DATE_FORMAT(created_at, '%Y-%m') = '$bulanIni'")->fetch_assoc()['total'] ?? 0;
$totalUkuran = @$koneksi->query("SELECT COALESCE(SUM(ukuran_file), 0) as total FROM arsip")->fetch_assoc()['total'] ?? 0;

// Arsip terbaru (5 terakhir)
$arsipTerbaru = $koneksi->query("
    SELECT a.*, k.nama_kategori 
    FROM arsip a 
    LEFT JOIN kategori k ON a.kategori_id = k.id 
    ORDER BY a.created_at DESC 
    LIMIT 5
");

// Statistik per kategori (TAMPILKAN SEMUA TANPA LIMIT)
$statKategori = $koneksi->query("
    SELECT k.id, k.nama_kategori, COUNT(a.id) as jumlah 
    FROM kategori k 
    LEFT JOIN arsip a ON k.id = a.kategori_id 
    GROUP BY k.id, k.nama_kategori 
    ORDER BY jumlah DESC
");

$pageTitle    = 'Dashboard';
$pageSubtitle = 'Ringkasan data arsip digital madrasah';
$activePage   = 'dashboard';

require_once __DIR__ . '/templates/header.php';

// ========================================================
// AREA CEK UPDATE REMOTE
// (Logic API server pusat untuk cek versi sistem terbaru)
// ========================================================
function check_update($current_version) {
    // Efisiensi: Lakukan request ke GitHub HANYA jika sesi update_checked belum ada
    if (!isset($_SESSION['update_checked'])) {
        try {
            // Konfigurasi timeout pendek agar aplikasi tidak hang saat internet mati
            $ctx = stream_context_create(['http' => ['timeout' => 2]]);
            
            // Hapus cache per sesi agar dapat langsung melihat sistem update bekerja saat ini
            unset($_SESSION['update_checked']); 
            unset($_SESSION['update_data']);

            // URL Pusat JSON Repository Asli
            $url = 'https://raw.githubusercontent.com/Danangcodee/E-Arsip-Update/refs/heads/main/update.json';
            
            // Ambil data tanpa error/warning menggunakan kutip @ 
            $json_data = @file_get_contents($url, false, $ctx);
            
            if ($json_data) {
                $data = json_decode($json_data, true);
                if ($data && isset($data['version'])) {
                    // Simpan data remote ke session
                    $_SESSION['update_data'] = $data;
                }
            }
        } catch (Exception $e) {
            // Fallback: Skip pengecekan jika gagal / internet down
        }
        
        // Tandai bahwa pengecekan sudah lewat (berhasil atau gagal), tidak memukul API terus menerus
        $_SESSION['update_checked'] = true; 
    }

    $result = [
        'tersedia' => false,
        'latest_version' => $current_version,
        'changelog' => ['Peningkatan performa dan kestabilan sistem'],
        'download_url' => '#'
    ];

    // Jika ada data di memory session
    if (isset($_SESSION['update_data']['version'])) {
        $result['latest_version'] = $_SESSION['update_data']['version'];
        
        // Evaluasi perbandingan versi menggunakan fungsi native PHP (misal 1.10.0 > 1.2.0)
        if (version_compare($result['latest_version'], $current_version, '>')) {
            $result['tersedia'] = true; 
            if (!empty($_SESSION['update_data']['changelog'])) {
                // Ubah string multiline changelog menjadi array berdasarkan line break
                $changelogStr = $_SESSION['update_data']['changelog'];
                if (is_string($changelogStr)) {
                    $result['changelog'] = array_filter(array_map('trim', explode("\n", $changelogStr)));
                } else {
                    $result['changelog'] = $changelogStr;
                }
            }
            if (!empty($_SESSION['update_data']['download_url'])) {
                $result['download_url'] = $_SESSION['update_data']['download_url'];
            }
        }
    }
    
    return $result;
}

// Menjalankan pengecekan dan mem-parsing nilainya ke variabel antarmuka (UI)
$update_info = check_update(APP_VERSION);
$update_tersedia = $update_info['tersedia'];
$latest_version_remote = $update_info['latest_version'];
$update_changelog = $update_info['changelog'];
$update_download_url = $update_info['download_url'];

// Waktu Dinamis untuk Sapaan
$jam = (int)date('H');
if ($jam >= 5 && $jam < 11) {
    $sapaan = 'Selamat Pagi';
} elseif ($jam >= 11 && $jam < 15) {
    $sapaan = 'Selamat Siang';
} elseif ($jam >= 15 && $jam < 18) {
    $sapaan = 'Selamat Sore';
} else {
    $sapaan = 'Selamat Malam';
}
?>

<div class="p-4 sm:p-6 lg:p-8 space-y-10">
    <!-- Cek Update Sistem -->
    <?php if (isset($update_tersedia) && $update_tersedia === true): ?>
    <div class="update-banner relative flex flex-col items-start gap-4 overflow-hidden rounded-[2rem] border border-emerald-500/30 bg-gradient-to-br from-emerald-500/10 to-emerald-950/20 p-6 shadow-2xl shadow-emerald-500/10 backdrop-blur-xl md:flex-row animate-in fade-in slide-in-from-top-4 duration-500 group">
        <!-- Efek Shimmer -->
        <div class="absolute inset-0 z-0 translate-x-[-100%] bg-gradient-to-r from-emerald-500/0 via-emerald-500/5 to-emerald-500/0 group-hover:animate-[shimmer_2s_infinite]"></div>
        
        <!-- Ikon -->
        <div class="z-10 flex h-14 w-14 shrink-0 items-center justify-center rounded-[1.25rem] bg-emerald-500 text-white shadow-lg shadow-emerald-500/40">
            <i class="fas fa-rocket text-2xl animate-pulse"></i>
        </div>
        
        <!-- Konten / Changelog -->
        <div class="z-10 flex-1 space-y-3">
            <h3 class="text-sm font-black uppercase tracking-widest text-emerald-400">
                Pembaruan Versi <?= htmlspecialchars($latest_version_remote) ?> Tersedia
            </h3>
            
            <ul class="space-y-2 text-[13px] font-semibold text-emerald-400/80">
                <?php if (!empty($update_changelog) && is_array($update_changelog)): ?>
                    <?php foreach ($update_changelog as $item): ?>
                    <li class="flex items-center gap-2">
                        <span class="text-emerald-500">✅</span> <?= htmlspecialchars($item) ?>
                    </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <li class="flex items-center gap-2"><span class="text-emerald-500">✅</span> Fitur Cetak Laporan PDF (Kop Madrasah)</li>
                    <li class="flex items-center gap-2"><span class="text-emerald-500">✅</span> Peningkatan performa dan kestabilan sistem</li>
                <?php endif; ?>
            </ul>
        </div>
        
        <!-- Tombol Aksi & Tutup -->
        <div class="z-10 mt-2 flex w-full shrink-0 flex-row items-center justify-end gap-3 md:mt-0 md:w-auto md:flex-col lg:flex-row lg:items-start">
            <form action="auto_update" method="POST" class="flex flex-1 w-full md:w-auto m-0 p-0">
                <input type="hidden" name="download_url" value="<?= htmlspecialchars($update_download_url) ?>">
                <input type="hidden" name="new_version" value="<?= htmlspecialchars($latest_version_remote) ?>">
                <button type="submit" onclick="this.innerHTML='<i class=\'fas fa-spinner fa-spin\'></i> PROSES MENGUNDUH...'; this.classList.add('opacity-70', 'cursor-not-allowed')" class="flex w-full flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-emerald-500 px-5 py-2.5 text-xs font-black uppercase tracking-widest text-white shadow-lg shadow-emerald-500/30 transition-all hover:scale-95 hover:bg-emerald-600 border-0">
                    <i class="fas fa-cloud-download-alt"></i> Install Pembaruan v<?= htmlspecialchars($latest_version_remote) ?>
                </button>
            </form>
            <button onclick="this.closest('.update-banner').remove()" class="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-white/5 bg-black/20 font-bold text-emerald-300 transition-all hover:border-red-500/50 hover:bg-red-500 hover:text-white">
                <i class="fas fa-times text-sm"></i>
            </button>
        </div>
    </div>
    <?php endif; ?>

    <!-- Welcome Header -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 class="text-3xl font-black tracking-tight text-white"><?= $sapaan ?>, <span class="text-emerald-400"><?= $_SESSION['nama_lengkap'] ?? 'Admin' ?></span></h1>
            <p class="mt-2 text-emerald-400/60 font-medium">Berikut adalah rangkasan arsip digital Madrasah hari ini.</p>
        </div>
        <div class="flex gap-3">
            <a href="<?= BASE_URL ?>/admin/upload" class="flex items-center gap-2 rounded-2xl bg-emerald-600 px-6 py-3 font-bold text-white shadow-lg shadow-emerald-600/20 hover:bg-emerald-500 transition-all active:scale-95">
                <i class="fas fa-plus"></i> Upload Baru
            </a>
        </div>
    </div>

    <!-- Analytics Cards -->
    <div class="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <!-- Stat 1 -->
        <div class="group relative rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur-xl transition-all hover:bg-white/10">
            <div class="flex items-center gap-4">
                <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-400">
                    <i class="fas fa-folder-open text-xl"></i>
                </div>
                <div>
                    <p class="text-xs font-black uppercase tracking-widest text-emerald-400/50">Total Arsip</p>
                    <h3 class="text-2xl font-black text-white"><?= number_format($totalArsip) ?></h3>
                </div>
            </div>
        </div>

        <!-- Stat 2 -->
        <div class="group relative rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur-xl transition-all hover:bg-white/10">
            <div class="flex items-center gap-4">
                <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-500/20 text-blue-400">
                    <i class="fas fa-tags text-xl"></i>
                </div>
                <div>
                    <p class="text-xs font-black uppercase tracking-widest text-blue-400/50">Kategori</p>
                    <h3 class="text-2xl font-black text-white"><?= number_format($totalKategori) ?></h3>
                </div>
            </div>
        </div>

        <!-- Stat 3 -->
        <div class="group relative rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur-xl transition-all hover:bg-white/10">
            <div class="flex items-center gap-4">
                <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-500/20 text-purple-400">
                    <i class="fas fa-calendar-check text-xl"></i>
                </div>
                <div>
                    <p class="text-xs font-black uppercase tracking-widest text-purple-400/50">Bulan Ini</p>
                    <h3 class="text-2xl font-black text-white"><?= number_format($arsipBulanIni) ?></h3>
                </div>
            </div>
        </div>

        <!-- Stat 4: Storage Usage -->
        <?php 
            $limitGB = 15;
            $limitBytes = $limitGB * 1024 * 1024 * 1024;
            $usagePercentage = ($totalUkuran / $limitBytes) * 100;
            // Pastikan tidak lebih dari 100% secara visual
            $progressWidth = min(100, $usagePercentage);
            $sizeMB = round($totalUkuran / (1024 * 1024), 2);
        ?>
        <div class="group relative rounded-[2rem] border border-white/10 bg-white/5 p-6 backdrop-blur-xl transition-all hover:bg-white/10">
            <div class="flex items-center gap-4 mb-4">
                <div class="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/20 text-amber-400">
                    <i class="fas fa-hdd text-xl"></i>
                </div>
                <div>
                    <p class="text-xs font-black uppercase tracking-widest text-amber-400/50">Penyimpanan</p>
                    <h3 class="text-xl font-black text-white"><?= $sizeMB ?> MB <span class="text-[10px] text-white/30 font-bold uppercase tracking-tighter">/ <?= $limitGB ?> GB</span></h3>
                </div>
            </div>
            <!-- Progress Bar -->
            <div class="w-full bg-white/5 rounded-full h-1.5 overflow-hidden border border-white/5">
                <div class="bg-gradient-to-r from-amber-500 to-orange-600 h-full transition-all duration-1000 shadow-[0_0_10px_rgba(245,158,11,0.5)]" style="width: <?= $progressWidth ?>%"></div>
            </div>
            <p class="mt-2 text-[9px] font-black text-white/20 uppercase tracking-[0.2em] text-right"><?= round($usagePercentage, 4) ?>% Terpakai</p>
        </div>
    </div>

    <!-- Main Content Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Recent Archives -->
        <div class="lg:col-span-2 space-y-4">
            <div class="flex items-center justify-between px-2">
                <h2 class="text-xl font-black uppercase tracking-widest text-emerald-300">📋 Arsip Terbaru</h2>
                <a href="<?= BASE_URL ?>/admin/arsip" class="text-xs font-bold text-emerald-400 hover:text-white transition-colors">Lihat Semua →</a>
            </div>
            
            <div class="rounded-[2.5rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-xl overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead class="bg-black/20 text-emerald-400/50 uppercase text-[10px] font-black tracking-widest">
                            <tr>
                                <th class="px-6 py-4">Dokumen</th>
                                <th class="px-6 py-4">Kategori</th>
                                <th class="px-6 py-4">Tanggal</th>
                                <th class="px-6 py-4 text-right">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-white/5">
                            <?php while ($row = $arsipTerbaru->fetch_assoc()): ?>
                            <tr class="hover:bg-white/5 transition-colors group">
                                <td class="px-6 py-5">
                                    <div class="flex items-center gap-3">
                                        <div class="h-10 w-10 flex items-center justify-center rounded-xl <?= strpos($row['tipe_file'], 'pdf') !== false ? 'bg-red-500/20 text-red-400' : 'bg-blue-500/20 text-blue-400' ?>">
                                            <i class="fas <?= strpos($row['tipe_file'], 'pdf') !== false ? 'fa-file-pdf' : 'fa-file-image' ?> text-lg"></i>
                                        </div>
                                        <div>
                                            <p class="font-bold text-white leading-tight"><?= sanitize($row['nama_arsip']) ?></p>
                                            <p class="text-[10px] text-white/30 truncate w-32"><?= sanitize($row['nama_file']) ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-5">
                                    <span class="rounded-full bg-emerald-500/10 px-3 py-1 text-[10px] font-black text-emerald-400 border border-emerald-500/10 uppercase">
                                        <?= sanitize($row['nama_kategori']) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-5 text-xs text-white/50 font-medium">
                                    <?= date('d M Y', strtotime($row['tanggal_arsip'])) ?>
                                </td>
                                <td class="px-6 py-5 text-right">
                                    <a href="<?= sanitize($row['gdrive_view_link']) ?>" target="_blank" class="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-white/50 hover:bg-emerald-500 hover:text-white transition-all shadow-lg">
                                        <i class="fas fa-eye text-xs"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Categories Sidebar -->
        <div class="space-y-4">
            <h2 class="text-xl font-black uppercase tracking-widest text-emerald-300 px-2">🏷️ Kategori</h2>
            <div class="rounded-[2.5rem] border border-white/10 bg-white/5 p-6 backdrop-blur-xl space-y-4 shadow-2xl">
                <?php 
                $icons = ['fa-folder', 'fa-book', 'fa-file-alt', 'fa-archive', 'fa-briefcase'];
                $i = 0;
                if ($statKategori->num_rows > 0):
                    while ($kat = $statKategori->fetch_assoc()): 
                ?>
                <a href="<?= BASE_URL ?>/admin/arsip?kategori=<?= $kat['id'] ?>" class="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-emerald-500/30 hover:bg-white/10 transition-all group no-underline text-left">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 flex items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400 group-hover:scale-110 transition-transform">
                            <i class="fas <?= $icons[$i % count($icons)] ?>"></i>
                        </div>
                        <div>
                            <p class="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors"><?= sanitize($kat['nama_kategori']) ?></p>
                            <p class="text-[10px] text-emerald-400/50 font-black uppercase"><?= $kat['jumlah'] ?> Dokumen</p>
                        </div>
                    </div>
                    <i class="fas fa-arrow-right text-[10px] text-white/20 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all"></i>
                </a>
                <?php $i++; endwhile; else: ?>
                    <p class="text-center text-white/30 italic text-sm py-4">Belum ada kategori.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>

