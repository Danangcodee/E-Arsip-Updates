<?php
/**
 * Application: E-Arsip Madrasah Digital
 * Developer: Tumenggung Danang Triharto
 * URL: https://admin.mtssmaarif02kotagajah.my.id
 * All Rights Reserved © 2026
 */
require_once __DIR__ . '/../config/koneksi.php';

// AKTIFKAN DEBUG MODE PENUH
error_reporting(E_ALL);
ini_set('display_errors', 1);

requireLogin();

// Keamanan: Hanya eksekusi jika dikirimkan melalui POST atau GET Bypass run=true
$isManualRun = isset($_GET['run']) && $_GET['run'] === 'true';

if (($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['download_url'])) || $isManualRun) {
    
    // Jika manual run, ambil link file zip yang baru saja Anda upload ke GitHub (Ganti sesuai nama repo mu)
    $url = $_POST['download_url'] ?? 'https://github.com/Danangcodee/E-Arsip-Update/raw/refs/heads/main/v1.1.0.zip';
    $rootDir = rtrim(__DIR__ . '/../', '/');
    $zipFile = $rootDir . '/master_update.zip';
    $tempDir = $rootDir . '/temp_update_folder';
    
    // Fungsi Logger Sederhana
    function write_update_log($message) {
        $logFile = rtrim(__DIR__ . '/../', '/') . '/update_debug.log';
        file_put_contents($logFile, date('[Y-m-d H:i:s] ') . $message . "\n", FILE_APPEND);
    }
    
    // Die Prevention: Cegah timeout 30 detik bawaan XAMPP/Laragon
    set_time_limit(300);

    try {
        // Hapus Log Lama agar riwayat lebih bersih khusus update sesi ini
        $logFile_path = rtrim(__DIR__ . '/../', '/') . '/update_debug.log';
        if (file_exists($logFile_path)) @unlink($logFile_path);

        write_update_log("=== MULAI PROSES AUTO-UPDATE ===");
        write_update_log("Mempersiapkan validasi ekstensi ZipArchive...");
        // 0. PRA-VALIDASI SISTEM & URL
        if (!is_writable($rootDir)) {
            throw new Exception("Error Keamanan Server: Folder utama E-Arsip di server Laragon/Hosting Anda menolak untuk ditulisi (Not Writable). Ubah hak akses izin folder (chmod / permission) terlebih dahulu.");
        }

        if (!class_exists('ZipArchive')) {
            throw new Exception("Error: Modul ZipArchive PHP belum aktif di Laragon! Silakan centang PHP > Extensions > zip");
        }
        
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            throw new Exception("URL Unduhan (download_url) tidak valid. Link: " . htmlspecialchars($url));
        }

        // 1. Download File ZIP dari GitHub menggunakan CURL
        write_update_log("Mulai mengunduh file ZIP menggunakan CURL dari: " . $url);
        
        $ch = curl_init($url);
        $fp = fopen($zipFile, 'w+');
        if ($fp === false) {
            throw new Exception("Gagal membuat file " . $zipFile . " di server. Periksa hak akses Write.");
        }
        
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Sangat penting untuk GitHub AWS Redirects
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_USERAGENT, 'E-Arsip-Updater-Bot/1.0');
        
        $curl_exec = curl_exec($ch);
        $curl_error = curl_error($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);
        
        if ($curl_exec === false) {
            throw new Exception("Kegagalan jaringan CURL: " . $curl_error);
        }
        
        if ($http_code < 200 || $http_code >= 400) {
            throw new Exception("Server merespons kode HTTP bermasalah: " . $http_code . ". Gagal mengambil file ZIP. Pastikan url repositorinya publik/valid.");
        }
        
        write_update_log("Berhasil mengunduh dokumen secara lengkap!");
        write_update_log("Mulai proses ekstraksi ZIP Archive...");

        // 2. Ekstrak File ZIP
        $zip = new ZipArchive;
        if ($zip->open($zipFile) === TRUE) {
            
            // Buat folder tampungan ekstraksi jika belum ada
            if (!is_dir($tempDir)) {
                mkdir($tempDir, 0755, true);
            }
            
            // Ekstrak secara mentah ke folder temp
            $zip->extractTo($tempDir);
            $zip->close();
            
            // GitHub otomatis membuat folder bungkus tambahan (contoh: E-Arsip-main/).
            // Kita wajib menelusuri nama folder bungkus tersebut (biasanya satu-satunya folder di dalam zip).
            $scan = scandir($tempDir);
            $githubWrapperFolder = '';
            foreach ($scan as $item) {
                if ($item !== '.' && $item !== '..' && is_dir($tempDir . '/' . $item)) {
                    $githubWrapperFolder = $item;
                    break;
                }
            }
            
            $sourcePath = empty($githubWrapperFolder) ? $tempDir : $tempDir . '/' . $githubWrapperFolder;
            
            // 3. Proses Timpa Ulang File Server Lokal (Recursively Move)
            function recursiveCopyMerge($src, $dst) {
                $dir = opendir($src);
                if (!is_dir($dst)) @mkdir($dst, 0755, true);
                
                while (false !== ($file = readdir($dir))) {
                    if (($file !== '.') && ($file !== '..')) {
                        $srcPath = $src . '/' . $file;
                        $dstPath = $dst . '/' . $file;
                        
                        // PROTEKSI SISTEM: JANGAN TIMPA KONFIGURASI PEMBELI & FILE INSTALASI!
                        $isProtected = false;
                        $protectedFiles = ['koneksi.php', 'gdrive-auth.json', 'install.lock', '.env'];
                        foreach ($protectedFiles as $prot) {
                            if (str_ends_with(strtolower($dstPath), strtolower($prot))) {
                                $isProtected = true;
                                break;
                            }
                        }
                        
                        if ($isProtected) {
                            continue; // Skip menimpa file krusial ini
                        }

                        if (is_dir($srcPath)) {
                            // Crossover directory
                            recursiveCopyMerge($srcPath, $dstPath);
                        } else {
                            // Salin Data (Overwrite)
                            @copy($srcPath, $dstPath);
                        }
                    }
                }
                closedir($dir);
            }

            // Lakukan Timpa data menembus Root Path Aplikasi Asli
            write_update_log("Salin rekursif dimulai: memindahkan file ekstraksi...");
            recursiveCopyMerge($sourcePath, $rootDir);
            write_update_log("Salin data sistem sukses dieksekusi!");

            // 4. Pembersihan Sisa Sampah
            write_update_log("Mulai pembersihan root dari berkas sementara...");
            // Hapus folder tampungan GitHub
            function deleteDirectory($dir) {
                if (!file_exists($dir)) return true;
                if (!is_dir($dir)) return unlink($dir);
                foreach (scandir($dir) as $item) {
                    if ($item == '.' || $item == '..') continue;
                    if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) return false;
                }
                return rmdir($dir);
            }
            
            deleteDirectory($tempDir);
            unlink($zipFile); // Hapus file ZIP
            
            // Hapus session checker lama, supaya besok aplikasi memuat update.json versi terbaru (Bypass Caching)
            unset($_SESSION['update_checked']);
            unset($_SESSION['update_data']);

            // Update nilai konfigurasi versi secara paralel ke koneksi dan version override
            $new_ver = $_POST['new_version'] ?? '1.1.0';
            
            // 1. Update di koneksi.php
            $kon_path = $rootDir . '/config/koneksi.php';
            if (file_exists($kon_path)) {
                $kon_data = file_get_contents($kon_path);
                $kon_data = preg_replace("/define\('APP_VERSION',\s*'.*?'\);/", "define('APP_VERSION', '$new_ver');", $kon_data);
                file_put_contents($kon_path, $kon_data);
            }
            
            // 2. Update di version.php (Faktor Paling Penting dari Temuan Terbaru)
            $ver_path = $rootDir . '/config/version.php';
            if (file_exists($ver_path)) {
                $ver_data = file_get_contents($ver_path);
                $ver_data = preg_replace("/\\\$app_version\s*=\s*'.*?';/", "\$app_version = '$new_ver';", $ver_data);
                file_put_contents($ver_path, $ver_data);
            }

            // Sukses: Gunakan SweetAlert CDN untuk popup melayang elegan (Bypass Die Page Putih)
            write_update_log("UPDATE SELESAI DENGAN MULUS.");
            
            die("
                <!DOCTYPE html>
                <html lang='id'>
                <head>
                    <title>Update Berhasil</title>
                    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
                    <style>body { background: #0f172a; font-family: sans-serif; margin: 0; display: flex; justify-content: center; align-items: center; height: 100vh; overflow: hidden; }</style>
                </head>
                <body>
                    <script>
                        Swal.fire({
                            title: 'Sistem Diperbarui!',
                            text: 'Pembaruan ke v$new_ver sukses mendarat. Seluruh database, token, dan identitas madrasah tetap aman terlindungi!',
                            icon: 'success',
                            background: '#1e293b',
                            color: '#f8fafc',
                            confirmButtonColor: '#10b981',
                            confirmButtonText: 'MANTAP! KEMBALI KE PUSAT',
                            allowOutsideClick: false
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = 'auto_update.php';
                            }
                        });
                    </script>
                </body>
                </html>
            ");

        } else {
            throw new Exception("File ZIP corrupt atau rusak. Gagal membongkar via ZipArchive.");
        }

    } catch (Exception $e) {
        // Kalau Gagal jangan biarkan file ZIP memenuhi memori
        if (file_exists($zipFile)) @unlink($zipFile);
        if (is_dir($tempDir)) @deleteDirectory($tempDir);
        
        // Manual Check Break: Die Sesuai Permintaan User (Tanpa JS JS an)
        $error_pesan = $e->getMessage();
        if (function_exists('write_update_log')) write_update_log("ERROR FATAL TERDETEKSI: " . $error_pesan);
        
        die("
            <div style='font-family:sans-serif; padding:40px; background:#fef2f2; color:#991b1b; border:2px solid #f87171; border-radius:12px; margin:30px;'>
                <h2 style='margin-top:0'>❌ GAGAL DOWNLOAD / EKSTRAK:</h2>
                <pre style='background:#fee2e2; padding:20px; font-size:14px; white-space:pre-wrap;'>$error_pesan</pre>
                <br>
                <p>Silakan pelajari error di atas atau baca file <strong>update_debug.log</strong> di folder root.</p>
                <button onclick=\"window.history.back()\" style='padding:10px 20px; font-weight:bold; cursor:pointer;'>Kembali</button>
            </div>
        ");
    }

} else {
    // ---------------------------------------------------------
    // HALAMAN PUSAT PEMBARUAN & RIWAYAT (UI FRIENDLY)
    // ---------------------------------------------------------
    $pageTitle    = 'Pusat Pembaruan';
    $pageSubtitle = 'Informasi versi sistem dan riwayat pembaruan otomatis';
    $activePage   = 'pusat_update';

    require_once __DIR__ . '/templates/header.php';
    
    // Ambil Data Log
    $logFile = rtrim(__DIR__ . '/../', '/') . '/update_debug.log';
    $isianLog = file_exists($logFile) ? htmlspecialchars(file_get_contents($logFile)) : "Tidak ada catatan aktivitas pembaruan. Sistem masih menggunakan versi bawaan instalasi.";
    
    // Ambil Data Info Changelog Terbaru dari Session jika ada
    $remoteVersion = $_SESSION['update_data']['version'] ?? 'Tidak diketahui';
    $changelog_arr = [];
    if (!empty($_SESSION['update_data']['changelog'])) {
        $ch_raw = $_SESSION['update_data']['changelog'];
        $changelog_arr = is_string($ch_raw) ? array_filter(array_map('trim', explode("\n", $ch_raw))) : $ch_raw;
    }
    ?>

    <div class="space-y-6">
        <!-- Informasi Versi Card -->
        <div class="relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-xl transition-all hover:bg-white/10 sm:p-8">
            <div class="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                <div>
                    <h3 class="flex items-center gap-3 text-xl font-bold text-white mb-2">
                        <i class="fas fa-server text-emerald-400"></i> Sistem E-Arsip Digital
                    </h3>
                    <p class="text-white/60 text-sm">Versi Saat Ini: <strong class="text-white font-mono bg-white/10 px-2 py-1 rounded">v<?= htmlspecialchars(APP_VERSION) ?></strong></p>
                </div>
                
                <?php
                // Validasi Cerdas: Cek apakah versi remote di GitHub LEBIH BESAR dari versi lokal
                $butuh_update = version_compare($remoteVersion, APP_VERSION, '>');
                
                if ($butuh_update && !empty($changelog_arr)): 
                ?>
                <div class="bg-black/20 p-4 rounded-xl border border-white/5 text-sm md:max-w-md">
                    <p class="text-emerald-400 font-bold mb-2"><i class="fas fa-magic"></i> Fitur Menanti di Versi <?= htmlspecialchars($remoteVersion) ?>:</p>
                    <ul class="text-white/70 space-y-1 mb-4">
                        <?php foreach ($changelog_arr as $c): ?>
                            <li><i class="fas fa-check text-emerald-500 mr-2 text-xs"></i> <?= htmlspecialchars($c) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    
                    <!-- TOMBOL UPDATE UTAMA DI SINI -->
                    <form method="POST" action="auto_update" class="m-0">
                        <input type="hidden" name="download_url" value="<?= htmlspecialchars($_SESSION['update_data']['download_url'] ?? '') ?>">
                        <input type="hidden" name="new_version" value="<?= htmlspecialchars($remoteVersion) ?>">
                        <button type="submit" onclick="this.innerHTML='<i class=\'fas fa-spinner fa-spin\'></i> SEDANG MENGUNDUH...'; this.classList.add('opacity-50', 'cursor-not-allowed')" class="w-full rounded-lg bg-emerald-500 px-4 py-2 font-bold text-white shadow hover:bg-emerald-600 transition tracking-wide text-xs">
                           <i class="fas fa-rocket mr-1"></i> INSTAL PEMBARUAN SEKARANG
                        </button>
                    </form>
                </div>
                <?php else: ?>
                <div class="bg-black/20 p-5 rounded-2xl border border-white/5 text-sm md:max-w-md w-full shadow-inner">
                    <div class="flex items-center gap-4 text-emerald-400">
                        <div class="bg-emerald-500/20 p-3 rounded-xl border border-emerald-500/30">
                            <i class="fas fa-shield-alt text-2xl"></i>
                        </div>
                        <div>
                            <span class="font-bold block text-base text-white">Sistem Terkini Mutakhir!</span>
                            <span class="text-white/50 text-xs block leading-relaxed max-w-[250px]">Anda sedang menggunakan E-Arsip versi paling mutakhir dan stabil.</span>
                        </div>
                    </div>
                    
                    <?php if (!empty($changelog_arr)): ?>
                    <div class="mt-4 border-t border-white/10 pt-4">
                        <p class="text-[10px] text-white/40 mb-3 font-bold uppercase tracking-widest"><i class="fas fa-history mr-1"></i> Telah Hadir di versi ini:</p>
                        <ul class="text-white/70 space-y-2">
                            <?php foreach ($changelog_arr as $c): ?>
                                <li class="text-xs flex items-start gap-2">
                                    <i class="fas fa-check-circle text-blue-500 mt-0.5"></i> 
                                    <span class="leading-tight"><?= htmlspecialchars($c) ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="mt-8 border-t border-white/10 pt-6">
                <p class="text-xs text-white/40 mb-3"><i class="fas fa-info-circle mr-1"></i> Jika terdapat pembaruan (*Update*), Notifikasi Instalasi akan muncul otomatis secara eksklusif hanya di halaman <strong>Dashboard Utama</strong> Anda.</p>
            </div>
        </div>

        <!-- Terminal Log Viewer (Penyederhanaan Mode Debug) -->
        <div class="relative overflow-hidden rounded-2xl border border-white/10 bg-black/40 backdrop-blur-xl">
            <div class="border-b border-white/5 bg-white/5 px-6 py-4 flex items-center justify-between">
                <h4 class="font-bold text-white/90 font-mono tracking-widest text-sm flex items-center gap-2">
                    <i class="fas fa-terminal text-blue-400"></i> LOG EKSEKUSI MESIN
                </h4>
            </div>
            <div class="p-6 overflow-x-auto">
                <pre class="font-mono text-xs text-emerald-400 leading-relaxed whitespace-pre-wrap"><code><?= $isianLog ?></code></pre>
            </div>
        </div>
    </div>

    <?php
    require_once __DIR__ . '/templates/footer.php';
    exit;
}
