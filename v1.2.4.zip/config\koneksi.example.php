<?php
/**
 * Application: E-Arsip Madrasah Digital
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('Asia/Jakarta');

// ===================================
// DATABASE CONFIG (AUTO GENERATED)
// ===================================
define('DB_HOST', '{{DB_HOST}}');
define('DB_NAME', '{{DB_NAME}}');
define('DB_USER', '{{DB_USER}}');
define('DB_PASS', '{{DB_PASS}}');

// ===================================
// APP CONFIG
// ===================================
define('APP_NAME', 'E-Arsip Digital');
define('APP_FULL_NAME', '{{APP_FULL_NAME}}');
define('SCHOOL_NAME', APP_FULL_NAME);
define('APP_CITY', '{{APP_CITY}}');
define('APP_VERSION', '1.1.1');

// Base URL Auto Detect
$protokol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://');
$doc_root = rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/');
$app_root = rtrim(str_replace('\\', '/', __DIR__), '/');
$base_path = str_replace($doc_root, '', dirname($app_root));
$base_url = $protokol . $_SERVER['HTTP_HOST'] . $base_path;
define('BASE_URL', $base_url);

// ===================================
// DATABASE CONNECTION
// ===================================
$koneksi = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($koneksi->connect_error) {
    die("Koneksi Database Gagal: " . $koneksi->connect_error);
}
$koneksi->set_charset("utf8mb4");

// ===================================
// HELPERS
// ===================================
function sanitize(?string $data): string {
    if ($data === null) return '';
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/auth/login.php');
        exit;
    }
}

function isAdmin(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isOperator(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'operator';
}

function formatTanggal(string $date): string {
    $bulan = [1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
    $timestamp = strtotime($date);
    return date('j', $timestamp) . " " . $bulan[(int)date('n', $timestamp)] . " " . date('Y', $timestamp);
}

function formatFileSize(int $bytes): string {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// ===================================
// TELEGRAM NOTIFICATION
// ===================================
define('TELEGRAM_BOT_TOKEN', '{{TELEGRAM_TOKEN}}');
define('TELEGRAM_CHAT_ID', '{{TELEGRAM_CHAT_ID}}');

function sendTelegramNotif(string $message): void {
    if (empty(TELEGRAM_BOT_TOKEN) || TELEGRAM_BOT_TOKEN === '{{TELEGRAM_TOKEN}}') return;
    
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $data = ['chat_id' => TELEGRAM_CHAT_ID, 'text' => $message, 'parse_mode' => 'HTML', 'disable_web_page_preview' => true];

    try {
        if (!function_exists('curl_init')) return;
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url, CURLOPT_POST => true, 
            CURLOPT_POSTFIELDS => http_build_query($data),
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 3,
            CURLOPT_SSL_VERIFYPEER => false, CURLOPT_CONNECTTIMEOUT => 3
        ]);
        @curl_exec($ch);
        @curl_close($ch);
    } catch (\Throwable $e) {}
}

function logActivity(string $action, string $details = ''): void {
    global $koneksi;
    if (!isset($_SESSION['user_id'])) return;
    
    $userId = $_SESSION['user_id'];
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    
    @$koneksi->query("INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES ('$userId', '$action', '$details', '$ip')");

    $userName = $_SESSION['nama_lengkap'] ?? 'Unknown';
    $waktu    = date('d/m/Y H:i:s');
    
    $telegramMsg  = "🔐 <b>ARSIP LOG: $action</b>\n👤 User: $userName\n📍 IP: $ip\n🕐 Waktu: $waktu\n🏫 " . SCHOOL_NAME;
    sendTelegramNotif($telegramMsg);
}
