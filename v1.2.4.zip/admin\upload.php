<?php
/**
 * ============================================================
 * UPLOAD ARSIP — E-Arsip Digital MTs Ma'arif 02 Kotagajah
 * ============================================================
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
requireLogin();

// Proses Upload
$uploadError   = '';
$uploadSuccess = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once __DIR__ . '/../config/gdrive.php';
    
    $namaArsipBase = trim($_POST['nama_arsip'] ?? '');
    $kategoriId    = (int) ($_POST['kategori_id'] ?? 0);
    $nomorSurat    = trim($_POST['nomor_surat'] ?? '');
    $tanggalArsip  = $_POST['tanggal_arsip'] ?? '';
    $deskripsi     = trim($_POST['deskripsi'] ?? '');
    
    if (empty($namaArsipBase)) {
        $uploadError = 'Nama arsip harus diisi!';
    } elseif ($kategoriId <= 0) {
        $uploadError = 'Pilih kategori arsip!';
    } elseif (empty($tanggalArsip)) {
        $uploadError = 'Tanggal arsip harus diisi!';
    } elseif (!isset($_FILES['file_arsip']) || empty($_FILES['file_arsip']['name'][0])) {
        $uploadError = 'File arsip harus dipilih!';
    } else {
        try {
            // Ambil Nama Kategori untuk Folder G-Drive
            $catQuery = $koneksi->query("SELECT nama_kategori FROM kategori WHERE id = $kategoriId");
            $catRow = $catQuery->fetch_assoc();
            $namaKategori = $catRow['nama_kategori'] ?? 'Lainnya';

            $totalFiles = count($_FILES['file_arsip']['name']);
            $successCount = 0;
            $userId = $_SESSION['user_id'];
            
            $koneksi->begin_transaction();

            for ($i = 0; $i < $totalFiles; $i++) {
                if ($_FILES['file_arsip']['error'][$i] === UPLOAD_ERR_OK) {
                    $tmpName = $_FILES['file_arsip']['tmp_name'][$i];
                    $fileName = $_FILES['file_arsip']['name'][$i];
                    $fileType = $_FILES['file_arsip']['type'][$i];
                    $fileSize = $_FILES['file_arsip']['size'][$i];
                    
                    // Jika > 1 file, tambahkan angka ke nama arsip supaya tidak membingungkan
                    $namaArsipFinal = $totalFiles > 1 ? $namaArsipBase . " (" . ($i + 1) . ")" : $namaArsipBase;

                    // Upload ke Google Drive
                    $result = uploadToGDrive($tmpName, $fileName, $fileType, $namaKategori);
                    
                    // Simpan ke database
                    $stmt = $koneksi->prepare("INSERT INTO arsip (nama_arsip, kategori_id, nomor_surat, tanggal_arsip, deskripsi, nama_file, tipe_file, ukuran_file, gdrive_file_id, gdrive_view_link, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param('sisssssissi', $namaArsipFinal, $kategoriId, $nomorSurat, $tanggalArsip, $deskripsi, $fileName, $fileType, $fileSize, $result['file_id'], $result['view_link'], $userId);
                    
                    if ($stmt->execute()) {
                        $successCount++;
                    } else {
                        throw new Exception('Database Error: ' . $stmt->error);
                    }
                    $stmt->close();
                }
            }
            
            $koneksi->commit();

            if ($successCount > 0) {
                logActivity('Upload Arsip', "Mengupload $successCount arsip baru untuk kategori \"$namaKategori\"");
                setFlash('success', "$successCount File Arsip berhasil diupload ke Google Drive! ✅");
                header('Location: ' . BASE_URL . '/admin/arsip');
                exit;
            } else {
                $uploadError = 'Semua file gagal diupload! Pastikan ukuran total tidak melebihi batas server.';
            }

        } catch (Exception $e) {
            $koneksi->rollback();
            $uploadError = $e->getMessage();
        }
    }
}

$pageTitle    = 'Upload Arsip';
$pageSubtitle = 'Upload dokumen ke Google Drive';
$activePage   = 'upload';

require_once __DIR__ . '/templates/header.php';
$kategoriList = $koneksi->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");
?>

<div class="p-4 sm:p-6 lg:p-8">
    <div class="mb-8">
        <h1 class="text-3xl font-extrabold tracking-tight text-white">Upload <span class="text-emerald-400">Arsip Baru</span></h1>
        <p class="mt-2 text-sm text-emerald-400/70">Pastikan file sesuai dengan format yang didukung.</p>
    </div>

    <div class="max-w-4xl rounded-[2.5rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl">
        <div class="rounded-[2.25rem] bg-gradient-to-br from-white/10 to-transparent p-6 sm:p-10">
            
            <?php if ($uploadError): ?>
            <div class="mb-8 rounded-2xl border border-red-500/30 bg-red-500/10 p-5 text-red-400 backdrop-blur-xl">
                <i class="fas fa-times-circle mr-2"></i> <?= sanitize($uploadError) ?>
            </div>
            <?php endif; ?>

            <form method="POST" action="" enctype="multipart/form-data" id="uploadForm" class="space-y-8">
                <div class="grid grid-cols-1 gap-8 md:grid-cols-2">
                    <!-- Nama Arsip -->
                    <div class="md:col-span-2">
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Nama Arsip *</label>
                        <input type="text" name="nama_arsip" required
                            class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 px-6 text-white placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
                            placeholder="Contoh: SK Pembagian Tugas Ganjil 2024" value="<?= sanitize($_POST['nama_arsip'] ?? '') ?>">
                    </div>

                    <!-- Kategori -->
                    <div>
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Kategori *</label>
                        <select name="kategori_id" required
                            class="w-full appearance-none rounded-2xl border border-white/10 bg-black/20 py-4 px-6 text-white transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10">
                            <option value="">— Pilih Kategori —</option>
                            <?php while ($kat = $kategoriList->fetch_assoc()): ?>
                            <option value="<?= $kat['id'] ?>" class="bg-gray-900 text-white"><?= sanitize($kat['nama_kategori']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!-- Nomor Surat -->
                    <div>
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Nomor Surat</label>
                        <input type="text" name="nomor_surat"
                            class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 px-6 text-white placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
                            placeholder="Contoh: 001/SK/MTs/2024" value="<?= sanitize($_POST['nomor_surat'] ?? '') ?>">
                    </div>

                    <!-- Tanggal -->
                    <div>
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Tanggal Arsip *</label>
                        <input type="date" name="tanggal_arsip" required
                            class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 px-6 text-white transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
                            value="<?= date('Y-m-d') ?>">
                    </div>

                    <!-- Deskripsi -->
                    <div class="md:col-span-2">
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Deskripsi / Catatan</label>
                        <textarea name="deskripsi" rows="3"
                            class="w-full rounded-2xl border border-white/10 bg-black/20 p-6 text-white placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
                            placeholder="Tambahkan keterangan tambahan jika perlu..."><?= sanitize($_POST['deskripsi'] ?? '') ?></textarea>
                    </div>

                    <!-- Dropzone -->
                    <div class="md:col-span-2">
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Pilih File Arsip (Bisa Lebih Dari 1) *</label>
                        <div id="dropZone" class="group relative flex cursor-pointer flex-col items-center justify-center rounded-[2rem] border-2 border-dashed border-white/10 bg-white/5 py-12 transition-all hover:border-emerald-500/50 hover:bg-emerald-500/5">
                            <input type="file" id="file_arsip" name="file_arsip[]" multiple class="hidden" required accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.rar,.jpg,.jpeg,.png,.webp">
                            <div class="mb-4 flex h-20 w-20 items-center justify-center rounded-3xl bg-emerald-500/10 text-emerald-400 group-hover:scale-110 transition-transform">
                                <i class="fas fa-cloud-upload-alt text-4xl"></i>
                            </div>
                            <h3 class="text-xl font-bold text-white text-center px-4">Klik atau Tarik File Ke Sini <br><span class="text-sm font-normal text-emerald-400/80">(Bisa blok beberapa file sekaligus)</span></h3>
                            <p class="mt-2 text-sm text-emerald-400/50 italic">PDF, Office, Gambar, ZIP</p>
                            <div id="fileInfo" class="mt-4 hidden rounded-xl bg-emerald-500 px-4 py-2 text-sm font-bold text-white shadow-lg text-center"></div>
                        </div>
                    </div>
                </div>

                <div class="pt-8">
                    <button type="submit" id="submitBtn" class="flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 py-5 font-black uppercase tracking-widest text-white transition-all hover:shadow-2xl hover:shadow-emerald-500/40 active:scale-95">
                        <i class="fas fa-upload text-xl"></i> Mulai Upload ke G-Drive
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Loading Overlay -->
<div id="loadingOverlay" class="fixed inset-0 z-[9999] hidden items-center justify-center bg-black/80 backdrop-blur-xl">
    <div class="text-center">
        <div class="mb-6 inline-flex h-24 w-24 items-center justify-center rounded-full border-4 border-emerald-500/20 border-t-emerald-500 animate-spin"></div>
        <h2 class="text-3xl font-black text-white">Mengupload...</h2>
        <p class="mt-3 text-emerald-400/70">Mohon jangan tutup halaman ini sampai proses selesai.</p>
    </div>
</div>

<script>
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('file_arsip');
    const fileInfo = document.getElementById('fileInfo');

    dropZone.addEventListener('click', () => fileInput.click());
    
    fileInput.addEventListener('change', function() {
        if (this.files.length > 0) {
            if (this.files.length === 1) {
                fileInfo.textContent = `✅ ${this.files[0].name} (${(this.files[0].size/1024/1024).toFixed(2)} MB)`;
            } else {
                let totalSize = 0;
                for(let i=0; i<this.files.length; i++) totalSize += this.files[i].size;
                fileInfo.innerHTML = `✅ <b>${this.files.length} File Terpilih</b> <br> Total Ukuran: ${(totalSize/1024/1024).toFixed(2)} MB`;
            }
            fileInfo.classList.remove('hidden');
        } else {
            fileInfo.classList.add('hidden');
        }
    });

    document.getElementById('uploadForm').addEventListener('submit', function(e) {
        document.getElementById('loadingOverlay').classList.remove('hidden');
        document.getElementById('loadingOverlay').classList.add('flex');
    });
</script>

<?php require_once __DIR__ . '/templates/footer.php'; ?>

