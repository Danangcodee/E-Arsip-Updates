<?php
/**
 * Application: E-Arsip Madrasah Digital
 * Fitur: Pencadangan Database & Kirim ke Telegram
 */
require_once __DIR__ . '/../config/koneksi.php';
requireLogin();

// Pastikan hanya admin yang bisa mem-backup database
if (($_SESSION['role'] ?? '') !== 'admin') {
    die("Akses Eksekutif Ditolak.");
}

// Menonaktifkan batas waktu eksekusi agar backup tidak terputus
ini_set('max_execution_time', 300);
ini_set('memory_limit', '256M');

$dbName = DB_NAME;
$tables = [];

// Ambil semua daftar tabel dalam database
$result = $koneksi->query("SHOW TABLES");
if ($result) {
    while ($row = $result->fetch_row()) {
        // Jangan di backup jika ada table temporer
        $tables[] = $row[0];
    }
} else {
    die("Gagal mengambil daftar tabel: " . $koneksi->error);
}

// Mulai mengisi string untuk SQL
$sqlContent = "-- ========================================================\n";
$sqlContent .= "-- PENCADANGAN DATABASE " . APP_FULL_NAME . "\n";
$sqlContent .= "-- Waktu Backup  : " . date("Y-m-d H:i:s") . "\n";
$sqlContent .= "-- Versi Sistem : " . APP_VERSION . "\n";
$sqlContent .= "-- ========================================================\n\n";

$sqlContent .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
$sqlContent .= "SET AUTOCOMMIT = 0;\n";
$sqlContent .= "START TRANSACTION;\n";
$sqlContent .= "SET time_zone = \"+07:00\";\n\n";
$sqlContent .= "/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;\n";
$sqlContent .= "/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;\n";
$sqlContent .= "/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;\n";
$sqlContent .= "/*!40101 SET NAMES utf8mb4 */;\n\n";

foreach ($tables as $table) {
    if (!$koneksi->query("SELECT 1 FROM `$table` LIMIT 1")) continue;
    
    $result = $koneksi->query("SELECT * FROM `$table`");
    $numFields = $result->field_count;
    
    // Struktur tabel
    $row2 = $koneksi->query("SHOW CREATE TABLE `$table`")->fetch_row();
    $sqlContent .= "\n-- --------------------------------------------------------\n\n";
    $sqlContent .= "--\n-- Struktur dari tabel `$table`\n--\n\n";
    $sqlContent .= "DROP TABLE IF EXISTS `$table`;\n";
    $sqlContent .= $row2[1] . ";\n\n";
    
    // Data dalam tabel (hanya jika ada)
    if ($result->num_rows > 0) {
        $sqlContent .= "--\n-- Dumping data untuk tabel `$table`\n--\n\n";
        
        // Membaca baris-baris data
        while ($row = $result->fetch_row()) {
            $sqlContent .= "INSERT INTO `$table` VALUES(";
            for ($j = 0; $j < $numFields; $j++) {
                if (isset($row[$j])) {
                    // Mencegah error pada kutip
                    $row[$j] = $koneksi->real_escape_string($row[$j]);
                    // Mencegah error baris baru (newline)
                    $row[$j] = str_replace("\n", "\\n", $row[$j]);
                    // Mencegah error Carriage Return
                    $row[$j] = str_replace("\r", "\\r", $row[$j]);
                    
                    $sqlContent .= '"' . $row[$j] . '"';
                } else {
                    $sqlContent .= "NULL";
                }
                if ($j < ($numFields - 1)) {
                    $sqlContent .= ",";
                }
            }
            $sqlContent .= ");\n";
        }
        $sqlContent .= "\n";
    }
}

$sqlContent .= "\nCOMMIT;\n\n";
$sqlContent .= "/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;\n";
$sqlContent .= "/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;\n";
$sqlContent .= "/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;\n";

// Menyiapkan format penamaan file
$filename = 'backup_db_' . date("Ymd_His") . '.sql';
$tempDir = __DIR__ . '/../assets/tmp';
if (!is_dir($tempDir)) {
    mkdir($tempDir, 0755, true);
}
$tempFile = $tempDir . '/' . $filename;
file_put_contents($tempFile, $sqlContent);

// Cek apakah fitur Kirim ke Telegram Aktif
$sendToTelegram = defined('TELEGRAM_BACKUP_DB') && TELEGRAM_BACKUP_DB === 'Y';
$telegramBotToken = defined('TELEGRAM_BOT_TOKEN') ? TELEGRAM_BOT_TOKEN : '';
$telegramChatId = defined('TELEGRAM_CHAT_ID') ? TELEGRAM_CHAT_ID : '';

// Jika Aktif & Konfigurasi Bot Tidak Kosong
if ($sendToTelegram && !empty($telegramBotToken) && $telegramBotToken !== '{{TELEGRAM_TOKEN}}' && !empty($telegramChatId) && $telegramChatId !== '{{TELEGRAM_CHAT_ID}}') {
    $url = "https://api.telegram.org/bot" . $telegramBotToken . "/sendDocument";
    $caption = "📦 *Backup Database E-Arsip*\n🏢 *" . APP_FULL_NAME . "*\n📅 " . date("d M Y H:i:s") . "\n👤 Dieksekusi : " . ($_SESSION['nama_lengkap'] ?? 'Admin');
    
    // PHP CURL File Upload
    $cFile = new CURLFile($tempFile, 'application/sql', $filename);
    $data = [
        'chat_id' => $telegramChatId,
        'document' => $cFile,
        'caption' => $caption,
        'parse_mode' => 'Markdown'
    ];
    
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_exec($ch);
        curl_close($ch);
    }
}

// Log Aktivitas
logActivity('Backup Database', 'Admin telah mencadangkan file database ' . $filename);

// Terakhir: Lempar (Download) file SQL ke browser pengguna
header('Content-Type: application/sql');
header("Content-Transfer-Encoding: ASCII"); 
header("Content-Disposition: attachment; filename=\"" . $filename . "\""); 
header('Content-Length: ' . filesize($tempFile));

// Hapus buffer kosong jika ada sebelum kirim ke browser
if (ob_get_length()) ob_clean(); 

readfile($tempFile);

// Hapus file sementara setelah didownload
unlink($tempFile);
exit;
