<?php
/**
 * ============================================================
 * ADMIN HEADER TEMPLATE
 * ============================================================
 * Include di awal setiap halaman admin.
 * Sebelum include, define: $pageTitle, $pageSubtitle, $activePage
 * ============================================================
 */
require_once __DIR__ . '/../../config/koneksi.php';
requireLogin();

$pageTitle    = $pageTitle    ?? 'Dashboard';
$pageSubtitle = $pageSubtitle ?? '';
$activePage   = $activePage   ?? 'dashboard';
$userName     = $_SESSION['user_nama'] ?? 'Admin';
$initials     = strtoupper(substr($userName, 0, 2));

// Ambil foto profil (Sistem Cerdas: Tidak akan Error 500 meskipun kolom foto tidak ada)
$uId = (int)($_SESSION['user_id'] ?? 0);
$userFoto = null;
try {
    $uRes = @$koneksi->query("SELECT foto FROM users WHERE id = $uId");
    if ($uRes && $uRes->num_rows > 0) {
        $uData = $uRes->fetch_assoc();
        $userFoto = $uData['foto'] ?? null;
    }
} catch (\Throwable $th) {
    // Abaikan jika kolom tidak ada
    $userFoto = null;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?> — <?= APP_FULL_NAME ?></title>
    
    <!-- Mencegah Flash layar gelap saat pindah halaman di Mode Terang -->
    <script>
        if (localStorage.getItem('theme-arsip') === 'light') {
            document.documentElement.setAttribute('data-theme', 'light');
        }
    </script>

    <meta name="description" content="<?= sanitize($pageTitle) ?> - Sistem E-Arsip Digital MTs Ma'arif 02 Kotagajah">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Tailwind CSS (Play CDN) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'ui-sans-serif', 'system-ui'],
                        outfit: ['Outfit', 'sans-serif'],
                    },
                    colors: {
                        emerald: {
                            50: '#f0fdf4',
                            100: '#dcfce7',
                            200: '#bbf7d0',
                            300: '#86efac',
                            400: '#4ade80',
                            500: '#22c55e',
                            600: '#16a34a',
                            700: '#15803d',
                            800: '#166534',
                            900: '#14532d',
                            950: '#064e3b', // Emerald Madrasah Deep
                        },
                    }
                }
            }
        }
    </script>
    
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css?v=<?= time() ?>">
</head>
<body>

<div class="admin-layout">
    <!-- Sidebar Overlay (Mobile) -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="triggerUltraSidebar()"></div>
    
    <!-- Sidebar -->
    <aside id="mainSidebar" class="sidebar">
        <div class="sidebar-header">
            <div class="logo-icon">📁</div>
            <div class="brand-text">
                <h3><?= APP_NAME ?></h3>
                <span class="flex items-center gap-1"><?= SCHOOL_NAME ?> <i class="fas fa-check-circle text-blue-500 text-[10px]"></i></span>
            </div>
        </div>
        
        <nav class="sidebar-nav">
            <div class="nav-section-title">Menu Utama</div>
            
            <a href="<?= BASE_URL ?>/admin/dashboard" class="nav-link <?= $activePage === 'dashboard' ? 'active' : '' ?>">
                <span class="nav-icon">📊</span>
                <span>Dashboard</span>
            </a>
            
            <a href="<?= BASE_URL ?>/admin/arsip" class="nav-link <?= $activePage === 'arsip' ? 'active' : '' ?>">
                <span class="nav-icon">📋</span>
                <span>Daftar Arsip</span>
            </a>
            
            <a href="<?= BASE_URL ?>/admin/upload" class="nav-link <?= $activePage === 'upload' ? 'active' : '' ?>">
                <span class="nav-icon">📤</span>
                <span>Upload Arsip</span>
            </a>
            
            <div class="nav-section-title">Pengaturan</div>
            
            <a href="<?= BASE_URL ?>/admin/kategori" class="nav-link <?= $activePage === 'kategori' ? 'active' : '' ?>">
                <span class="nav-icon">🏷️</span>
                <span>Kategori</span>
            </a>

            <?php if (($_SESSION['role'] ?? '') === 'admin'): ?>
            <a href="<?= BASE_URL ?>/admin/users" class="nav-link <?= $activePage === 'users' ? 'active' : '' ?>">
                <span class="nav-icon"><i class="fas fa-users-cog"></i></span>
                <span>Manajemen User</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/pengaturan" class="nav-link <?= $activePage === 'pengaturan' ? 'active' : '' ?>">
                <span class="nav-icon"><i class="fas fa-cog"></i></span>
                <span>Pengaturan Sistem</span>
            </a>
            <a href="<?= BASE_URL ?>/admin/auto_update" class="nav-link <?= $activePage === 'pusat_update' ? 'active' : '' ?>">
                <span class="nav-icon text-emerald-400 group-hover:text-emerald-300"><i class="fas fa-cloud-download-alt"></i></span>
                <span class="text-emerald-50 font-medium">Pusat Pembaruan</span>
            </a>
            <?php endif; ?>

            <a href="<?= BASE_URL ?>/admin/riwayat" class="nav-link <?= $activePage === 'riwayat' ? 'active' : '' ?>">
                <span class="nav-icon"><i class="fas fa-history"></i></span>
                <span>Riwayat Aktivitas</span>
            </a>

            <div class="mt-auto px-4 mb-6">
                <p class="text-[10px] font-medium tracking-wide text-white/40 pl-3 border-l border-white/10 leading-relaxed" style="font-family: var(--font-outfit);">
                    <span class="text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30 inline-block mb-3 whitespace-nowrap">v<?= APP_VERSION ?></span> 
                    <br>
                    <span class="opacity-80">&copy; <?= date('Y') ?> Sistem Informasi Pengarsipan</span>
                </p>
            </div>
        </nav>
    </aside>

    <!-- Overlay sidebar untuk mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay2" onclick="triggerUltraSidebar()"></div>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Topbar -->
        <header class="topbar">
            <div class="topbar-left" style="display:flex;align-items:center;gap:12px;">
                <button type="button" class="mobile-toggle p-3" onclick="triggerUltraSidebar();" aria-label="Toggle menu" style="z-index: 1001 !important; position: relative;">☰</button>
                <div>
                    <h1><?= sanitize($pageTitle) ?></h1>
                    <?php if ($pageSubtitle): ?>
                    <p><?= sanitize($pageSubtitle) ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="topbar-right flex items-center h-full relative gap-2 sm:gap-4">
                <!-- Theme Toggle Button -->
                <button type="button" id="themeToggleBtn" onclick="toggleTheme()" class="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/5 border border-white/10 text-emerald-400 hover:bg-white/10 hover:text-emerald-300 shadow-md transition-all active:scale-95">
                    <i class="fas fa-moon text-lg" id="themeIcon"></i>
                </button>
            
                <!-- Dropdown Trigger -->
                <div class="user-info cursor-pointer hover:bg-white/5 p-1.5 pr-2.5 rounded-2xl transition-all" onclick="toggleUserDropdown(event)">
                    <div class="user-text text-right hidden sm:block mr-3">
                        <div class="user-name font-bold text-white leading-none mb-1"><?= sanitize($userName) ?></div>
                        <div class="user-role text-[10px] font-black uppercase tracking-widest text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full inline-block border border-emerald-500/20">
                            <?= ($_SESSION['role'] ?? '') === 'admin' ? 'Administrator' : 'Staf Operator' ?>
                        </div>
                    </div>
                    <?php if ($userFoto): ?>
                        <div class="user-avatar overflow-hidden">
                            <img src="<?= BASE_URL ?>/assets/img/profile/<?= $userFoto ?>" class="w-full h-full object-cover">
                        </div>
                    <?php else: ?>
                        <div class="user-avatar"><?= $initials ?></div>
                    <?php endif; ?>
                </div>

                <!-- Profile Dropdown Menu -->
                <div id="userDropdown" class="absolute right-0 top-full mt-5 w-48 rounded-3xl border border-white/10 bg-[#0f172a]/95 backdrop-blur-3xl p-1.5 shadow-2xl hidden opacity-0 translate-y-2 transition-all duration-300 z-[1002]">
                    <a href="<?= BASE_URL ?>/admin/profile" class="nav-link-profile flex items-center gap-2.5 p-2.5 rounded-2xl hover:bg-white/10 text-white no-underline transition-all">
                        <i class="fas fa-user-circle text-emerald-400 text-base"></i>
                        <span class="text-xs font-bold">Profil Saya</span>
                    </a>
                    <div class="h-px bg-white/5 my-1"></div>
                    <a href="javascript:void(0)" onclick="showLogoutModal()" class="flex items-center gap-2.5 p-2.5 rounded-2xl hover:bg-red-500/10 text-red-400 no-underline transition-all">
                        <i class="fas fa-sign-out-alt text-base"></i>
                        <span class="text-xs font-bold">Keluar</span>
                    </a>
                </div>
            </div>
        </header>
        
        <!-- Content Area -->
        <div class="content-area">
            <?php
            // Flash messages
            $flash = getFlash();
            if ($flash):
            ?>
            <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : ($flash['type'] === 'error' ? 'error' : ($flash['type'] === 'warning' ? 'warning' : 'info')) ?>">
                <span><?= $flash['type'] === 'success' ? '✅' : ($flash['type'] === 'error' ? '❌' : '⚠️') ?></span>
                <span><?= sanitize($flash['message']) ?></span>
            </div>
            <?php endif; ?>

<!-- MODAL LOGOUT KEREN (CUSTOM GLASS) -->
<div id="logoutModal" class="fixed inset-0 z-[99999] hidden items-center justify-center p-6 bg-black/80 backdrop-blur-md transition-all duration-300">
    <div class="w-full max-w-sm rounded-[2.5rem] border border-white/20 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl animate-in fade-in zoom-in duration-300">
        <div class="rounded-[2.25rem] bg-gradient-to-br from-white/10 to-transparent p-8 text-center space-y-6">
            <div class="mx-auto w-20 h-20 rounded-3xl bg-red-600/20 text-red-500 flex items-center justify-center text-4xl shadow-inner border border-red-500/20">
                <i class="fas fa-door-open"></i>
            </div>
            
            <div class="space-y-2">
                <h3 class="text-2xl font-black text-white uppercase tracking-widest italic">MAU KELUAR?</h3>
                <p class="text-sm text-emerald-400/50 font-medium">Pastikan semua pekerjaan Anda telah tersimpan dengan benar.</p>
            </div>

            <div class="grid grid-cols-1 gap-3 pt-4">
                <a href="<?= BASE_URL ?>/auth/logout" class="rounded-2xl bg-red-600 py-4 font-black uppercase tracking-widest text-white shadow-lg shadow-red-600/20 hover:bg-red-500 transition-all active:scale-95 no-underline">
                    Ya, Keluar Sekarang
                </a>
                <button onclick="closeLogoutModal()" class="rounded-2xl bg-white/5 border border-white/10 py-4 font-black uppercase tracking-widest text-white hover:bg-white/10 transition-all active:scale-95">
                    Tetap Di Sini
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function showLogoutModal() {
    const modal = document.getElementById('logoutModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

// --- THEME TOGGLE (NIGHT LIGHT MODE) ---
function initTheme() {
    const savedTheme = localStorage.getItem('theme-arsip');
    const html = document.documentElement;
    const icon = document.getElementById('themeIcon');
    
    if (savedTheme === 'light') {
        html.setAttribute('data-theme', 'light');
        if(icon) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        }
    }
}
initTheme(); // Panggil segera

function toggleTheme() {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    if (newTheme === 'light') {
        html.setAttribute('data-theme', 'light');
        localStorage.setItem('theme-arsip', 'light');
    } else {
        html.removeAttribute('data-theme');
        localStorage.setItem('theme-arsip', 'dark');
    }
    
    // Update Icon
    const icon = document.getElementById('themeIcon');
    if (icon) {
        if (newTheme === 'light') {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
            icon.classList.remove('text-emerald-400');
            icon.classList.add('text-amber-500'); // Warna icon untuk light mode
        } else {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon');
            icon.classList.remove('text-amber-500');
            icon.classList.add('text-emerald-400'); // Balikkan ke emerald
        }
    }
}

// --- USER DROPDOWN ---
function toggleUserDropdown(event) {
    if (event) event.stopPropagation();
    const dropdown = document.getElementById('userDropdown');
    const isHidden = dropdown.classList.contains('hidden');
    
    // Tutup semua dropdown lain jika ada
    if (isHidden) {
        dropdown.classList.remove('hidden');
        setTimeout(() => {
            dropdown.classList.remove('opacity-0', 'translate-y-2');
        }, 10);
    } else {
        closeUserDropdown();
    }
}

function closeUserDropdown() {
    const dropdown = document.getElementById('userDropdown');
    if (!dropdown.classList.contains('hidden')) {
        dropdown.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => {
            dropdown.classList.add('hidden');
        }, 300);
    }
}

// Tutup dropdown jika klik di mana saja
window.addEventListener('click', () => {
    closeUserDropdown();
});

function closeLogoutModal() {
    const modal = document.getElementById('logoutModal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

// --- SIDEBAR PERSISTENCE (INGAT POSISI TERAKHIR) ---
(function() {
    const savedState = localStorage.getItem('sidebar-collapsed');
    if (savedState === 'true' && window.innerWidth > 768) {
        document.body.classList.add('sidebar-collapsed');
    }
})();

// --- UNIFIED ULTRA SIDEBAR TOGGLE ---
function triggerUltraSidebar() {
    const sidebar = document.getElementById('mainSidebar') || document.querySelector('.sidebar');
    const overlays = document.querySelectorAll('.sidebar-overlay');
    const body = document.body;
    
    if (!sidebar) return;
    
    const isMobile = window.innerWidth <= 768;

    if (isMobile) {
        sidebar.classList.toggle('open');
        overlays.forEach(overlay => overlay.classList.toggle('active'));
        body.classList.toggle('no-scroll');
    } else {
        body.classList.toggle('sidebar-collapsed');
        // Simpan status terakhir ke memori browser
        const isCollapsed = body.classList.contains('sidebar-collapsed');
        localStorage.setItem('sidebar-collapsed', isCollapsed);
    }
}

// Tutup modal jika klik di luar area modal
document.getElementById('logoutModal').addEventListener('click', (e) => {
    if (e.target.id === 'logoutModal') closeLogoutModal();
});
</script>
