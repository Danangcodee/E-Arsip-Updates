<?php
/**
 * Application: E-Arsip Madrasah Digital
 * Pseudo-Cron Job untuk Auto Backup Database via Telegram
 */
require_once __DIR__ . '/../config/koneksi.php';

// Pastikan fitur diaktifkan dan bukan mode manual
if (!defined('TELEGRAM_BACKUP_DB') || TELEGRAM_BACKUP_DB !== 'Y') exit("Fitur Nonaktif");
if (!defined('TELEGRAM_BACKUP_PERIOD') || TELEGRAM_BACKUP_PERIOD === 'manual') exit("Mode Manual");
if (empty(TELEGRAM_BOT_TOKEN) || TELEGRAM_BOT_TOKEN === '{{TELEGRAM_TOKEN}}') exit("Token Kosong");
if (empty(TELEGRAM_CHAT_ID) || TELEGRAM_CHAT_ID === '{{TELEGRAM_CHAT_ID}}') exit("Chat ID Kosong");

$currentTime = time();
$lastBackup = defined('TELEGRAM_LAST_BACKUP') ? (int)TELEGRAM_LAST_BACKUP : 0;
$targetTimeStr = defined('TELEGRAM_BACKUP_TIME') ? TELEGRAM_BACKUP_TIME : '00:00';

$todayTargetTimestamp = strtotime(date('Y-m-d') . ' ' . $targetTimeStr . ':00');
$shouldBackup = false;

// Periksa kelayakan waktu
if ($currentTime >= $todayTargetTimestamp) {
    if ($lastBackup < $todayTargetTimestamp) {
        $diffSeconds = $currentTime - $lastBackup;
        
        switch (TELEGRAM_BACKUP_PERIOD) {
            case 'daily':
                $shouldBackup = true;
                break;
            case 'weekly':
                // Setidaknya sudah lewat 6.9 hari sejak update terakhir
                if ($diffSeconds >= (86400 * 6.5)) {
                    $shouldBackup = true;
                }
                break;
            case 'monthly':
                // Setidaknya lewat 28 hari
                if ($diffSeconds >= (86400 * 28)) {
                    $shouldBackup = true;
                }
                break;
        }
    }
}

// Jika belum waktunya, keluar
if (!$shouldBackup) {
    exit("Belum Waktunya");
}

/* ============================================================
   PROSES PEMBUATAN DATABASE SQL (BACKGROUND PROCESS)
   ============================================================ */
ini_set('max_execution_time', 300);
ini_set('memory_limit', '256M');

$tables = [];
$result = $koneksi->query("SHOW TABLES");
if ($result) {
    while ($row = $result->fetch_row()) {
        $tables[] = $row[0];
    }
} else {
    exit("Gagal Load Table");
}

$sqlContent = "-- ========================================================\n";
$sqlContent .= "-- PENCADANGAN AUTO DATABASE " . APP_FULL_NAME . "\n";
$sqlContent .= "-- Waktu Backup : " . date("Y-m-d H:i:s") . "\n";
$sqlContent .= "-- Periode      : " . strtoupper(TELEGRAM_BACKUP_PERIOD) . "\n";
$sqlContent .= "-- ========================================================\n\n";

$sqlContent .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
$sqlContent .= "SET AUTOCOMMIT = 0;\n";
$sqlContent .= "START TRANSACTION;\n";
$sqlContent .= "SET time_zone = \"+07:00\";\n\n";

foreach ($tables as $table) {
    if (!$koneksi->query("SELECT 1 FROM `$table` LIMIT 1")) continue;
    
    $result = $koneksi->query("SELECT * FROM `$table`");
    $numFields = $result->field_count;
    
    $row2 = $koneksi->query("SHOW CREATE TABLE `$table`")->fetch_row();
    $sqlContent .= "DROP TABLE IF EXISTS `$table`;\n";
    $sqlContent .= $row2[1] . ";\n\n";
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_row()) {
            $sqlContent .= "INSERT INTO `$table` VALUES(";
            for ($j = 0; $j < $numFields; $j++) {
                if (isset($row[$j])) {
                    $row[$j] = $koneksi->real_escape_string($row[$j]);
                    $row[$j] = str_replace("\n", "\\n", $row[$j]);
                    $row[$j] = str_replace("\r", "\\r", $row[$j]);
                    $sqlContent .= '"' . $row[$j] . '"';
                } else {
                    $sqlContent .= "NULL";
                }
                if ($j < ($numFields - 1)) {
                    $sqlContent .= ",";
                }
            }
            $sqlContent .= ");\n";
        }
        $sqlContent .= "\n";
    }
}
$sqlContent .= "\nCOMMIT;\n";

// Buat File Sementara
$filename = 'auto_backup_' . date("Ymd_His") . '.sql';
$tempDir = __DIR__ . '/../assets/tmp';
if (!is_dir($tempDir)) mkdir($tempDir, 0755, true);
$tempFile = $tempDir . '/' . $filename;
file_put_contents($tempFile, $sqlContent);

// Kirim ke Telegram
$url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendDocument";
$caption = "⚙️ *Auto Backup Terselesaikan*\n🏢 *" . APP_FULL_NAME . "*\n📅 " . date("d M Y H:i:s") . "\n🔄 Skema: " . ucfirst(TELEGRAM_BACKUP_PERIOD);
$cFile = new CURLFile($tempFile, 'application/sql', $filename);
$data = [
    'chat_id' => TELEGRAM_CHAT_ID,
    'document' => $cFile,
    'caption' => $caption,
    'parse_mode' => 'Markdown'
];

if (function_exists('curl_init')) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    // Asynchronous Execution via cURL
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    // Jika berhasil dikirim, catat waktunya agar tidak double
    if ($httpCode === 200) {
        $koneksiPath = __DIR__ . '/../config/koneksi.php';
        if (file_exists($koneksiPath)) {
            $content = file_get_contents($koneksiPath);
            $content = preg_replace("/define\('TELEGRAM_LAST_BACKUP',\s*['\"].*?['\"]\);/", "define('TELEGRAM_LAST_BACKUP', '" . $currentTime . "');", $content);
            file_put_contents($koneksiPath, $content);
        }
    }
}

// Bersihkan memory
unlink($tempFile);
exit("Selesai");
