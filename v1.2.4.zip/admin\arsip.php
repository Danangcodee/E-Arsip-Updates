<?php
/**
 * ============================================================
 * DAFTAR ARSIP — E-Arsip Digital MTs Ma'arif 02 Kotagajah
 * ============================================================
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
requireLogin();

// ============================================================
// PROSES HAPUS ARSIP (SATUAN)
// ============================================================
if (isset($_GET['hapus']) && is_numeric($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    require_once __DIR__ . '/../config/gdrive.php';
    
    $stmt = $koneksi->prepare("SELECT gdrive_file_id, nama_arsip FROM arsip WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $arsip = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($arsip) {
        if (!empty($arsip['gdrive_file_id'])) {
            try { deleteFromGDrive($arsip['gdrive_file_id']); } catch (Exception $e) {}
        }
        $stmt = $koneksi->prepare("DELETE FROM arsip WHERE id = ?");
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) { 
            // Catat Log
            logActivity('Hapus Arsip', "Menghapus arsip: \"{$arsip['nama_arsip']}\"");
            
            setFlash('success', "Arsip \"{$arsip['nama_arsip']}\" berhasil dihapus."); 
        }
        $stmt->close();
    }
    header('Location: arsip');
    exit;
}

// MODAL AJAX: Hentikan output header jika permintaan lewat AJAX
$isAjax = isset($_GET['ajax']);

if (!$isAjax) {
    $pageTitle    = 'Daftar Arsip';
    $pageSubtitle = 'Kelola semua arsip digital madrasah';
    $activePage   = 'arsip';
    require_once __DIR__ . '/templates/header.php';
}

// Filter & Pencarian
$search   = trim($_GET['q'] ?? '');
$kategori = (int) ($_GET['kategori'] ?? 0);
$page     = max(1, (int) ($_GET['page'] ?? 1));
$perPage  = 15;
$offset   = ($page - 1) * $perPage;

$where  = "WHERE 1=1";
$params = [];
$types  = '';

$tipeFile = trim($_GET['tipe'] ?? '0');
$periode = $_GET['periode'] ?? 'semua';
$tglMulai = $_GET['tgl_mulai'] ?? '';
$tglAkhir = $_GET['tgl_akhir'] ?? '';

if ($search) {
    $where .= " AND (a.nama_arsip LIKE ? OR a.nomor_surat LIKE ? OR a.deskripsi LIKE ?)";
    $searchParam = "%$search%";
    $params[] = &$searchParam; $params[] = &$searchParam; $params[] = &$searchParam;
    $types .= 'sss';
}
if ($kategori > 0) {
    $where .= " AND a.kategori_id = ?";
    $params[] = &$kategori;
    $types .= 'i';
}
if ($tipeFile !== '0') {
    if ($tipeFile === 'pdf') {
        $where .= " AND a.tipe_file LIKE '%pdf%'";
    } elseif ($tipeFile === 'image') {
        $where .= " AND (a.tipe_file LIKE '%image%' OR a.nama_file LIKE '%.jpg' OR a.nama_file LIKE '%.jpeg' OR a.nama_file LIKE '%.png' OR a.nama_file LIKE '%.webp')";
    } elseif ($tipeFile === 'word') {
        $where .= " AND (a.nama_file LIKE '%.doc' OR a.nama_file LIKE '%.docx' OR a.tipe_file LIKE '%word%')";
    } elseif ($tipeFile === 'excel') {
        $where .= " AND (a.nama_file LIKE '%.xls' OR a.nama_file LIKE '%.xlsx' OR a.tipe_file LIKE '%excel%' OR a.tipe_file LIKE '%spreadsheet%')";
    } elseif ($tipeFile === 'powerpoint') {
        $where .= " AND (a.nama_file LIKE '%.ppt' OR a.nama_file LIKE '%.pptx' OR a.tipe_file LIKE '%powerpoint%' OR a.tipe_file LIKE '%presentation%')";
    } elseif ($tipeFile === 'archive') {
        $where .= " AND (a.nama_file LIKE '%.zip' OR a.nama_file LIKE '%.rar' OR a.tipe_file LIKE '%zip%' OR a.tipe_file LIKE '%rar%')";
    }
}

// Filter Periode
switch ($periode) {
    case 'hari':
        $where .= " AND DATE(a.created_at) = CURDATE()";
        break;
    case '7hari':
        $where .= " AND a.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
        break;
    case 'bulan':
        $where .= " AND MONTH(a.created_at) = MONTH(CURDATE()) AND YEAR(a.created_at) = YEAR(CURDATE())";
        break;
    case 'tahun':
        $where .= " AND YEAR(a.created_at) = YEAR(CURDATE())";
        break;
    case 'custom':
        if ($tglMulai && $tglAkhir) {
            $where .= " AND DATE(a.created_at) BETWEEN ? AND ?";
            $params[] = &$tglMulai;
            $params[] = &$tglAkhir;
            $types .= 'ss';
        }
        break;
}


$countQuery = "SELECT COUNT(*) as total FROM arsip a $where";
$stmtCount = $koneksi->prepare($countQuery);
if ($types) $stmtCount->bind_param($types, ...$params);
$stmtCount->execute();
$totalData = $stmtCount->get_result()->fetch_assoc()['total'];
$stmtCount->close();
$totalPages = ceil($totalData / $perPage);

$query = "SELECT a.*, k.nama_kategori FROM arsip a LEFT JOIN kategori k ON a.kategori_id = k.id $where ORDER BY a.created_at DESC LIMIT $perPage OFFSET $offset";
$stmtData = $koneksi->prepare($query);
if ($types) $stmtData->bind_param($types, ...$params);
$stmtData->execute();
$result = $stmtData->get_result(); // Changed $arsipList to $result
$stmtData->close();

$kategoriList = $koneksi->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");

if (!$isAjax): // Only render full page if not an AJAX request
?>

<div class="p-4 sm:p-6 lg:p-8 space-y-6">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 class="text-3xl font-black tracking-tight text-white italic lowercase tracking-widest text-center md:text-left">
                <i class="fas fa-boxes text-emerald-500 mr-2"></i>Semua <span class="text-emerald-400 uppercase">Arsip</span>
            </h1>
            <p class="mt-2 text-emerald-400/60 font-medium text-center md:text-left">
                Ditemukan <strong id="totalDataCount"><?= number_format($totalData) ?></strong> data di sistem.
            </p>
        </div>
        <div class="flex flex-wrap justify-center md:justify-end gap-3">
             <a href="cetak?q=<?= urlencode($search) ?>&kategori=<?= $kategori ?>&periode=<?= $periode ?>&tgl_mulai=<?= $tglMulai ?>&tgl_akhir=<?= $tglAkhir ?>" id="btnPrintDraft" target="_blank" class="flex items-center gap-2 rounded-xl bg-white/5 px-6 py-3 font-bold text-white border border-white/10 hover:bg-emerald-500/10 transition-all active:scale-95">
                <i class="fas fa-file-pdf"></i> Cetak Laporan
            </a>
            <a href="upload" class="flex items-center gap-2 rounded-xl bg-emerald-600 px-6 py-3 font-bold text-white shadow-lg shadow-emerald-600/20 hover:bg-emerald-500 transition-all active:scale-95">
                <i class="fas fa-plus"></i> Upload Baru
            </a>
        </div>
    </div>

    <!-- Toolbar Pencarian & Filter -->
    <div class="rounded-[2rem] border border-white/10 bg-white/5 p-4 backdrop-blur-xl">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div class="relative md:col-span-2">
                <i class="fas fa-search absolute left-6 top-1/2 -translate-y-1/2 text-white/20"></i>
                <input type="text" id="liveSearchInput" placeholder="Ketik kata kunci (Nama, No Surat, Deskripsi)..." value="<?= sanitize($search) ?>"
                    class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 pl-14 pr-6 text-white placeholder-white/20 focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all">
                
                <!-- Spinner Manual CSS -->
                <style>
                @keyframes spin-manual { from { transform: translateY(-50%) rotate(0deg); } to { transform: translateY(-50%) rotate(360deg); } }
                .animate-spin-manual { animation: spin-manual 1s linear infinite; }
                </style>
                <div id="searchSpinner" class="absolute right-6 top-1/2 hidden border-2 border-emerald-500/20 border-t-emerald-500 h-5 w-5 rounded-full animate-spin-manual"></div>
            </div>
            <div>
                <select id="categoryFilter" class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 px-6 text-white focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 appearance-none cursor-pointer">
                    <option value="0" class="bg-gray-900 text-white">Semua Kategori</option>
                    <?php $kategoriList->data_seek(0); while ($kat = $kategoriList->fetch_assoc()): ?>
                    <option value="<?= $kat['id'] ?>" <?= $kategori == $kat['id'] ? 'selected' : '' ?> class="bg-gray-900 text-white border-none"><?= sanitize($kat['nama_kategori']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <select id="periodeFilter" class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 px-6 text-white focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 appearance-none cursor-pointer">
                    <option value="semua" class="bg-gray-900 text-white" <?= $periode == 'semua' ? 'selected' : '' ?>>Semua Waktu</option>
                    <option value="hari" class="bg-gray-900 text-white" <?= $periode == 'hari' ? 'selected' : '' ?>>Hari Ini</option>
                    <option value="7hari" class="bg-gray-900 text-white" <?= $periode == '7hari' ? 'selected' : '' ?>>7 Hari Terakhir</option>
                    <option value="bulan" class="bg-gray-900 text-white" <?= $periode == 'bulan' ? 'selected' : '' ?>>Bulan Ini</option>
                    <option value="tahun" class="bg-gray-900 text-white" <?= $periode == 'tahun' ? 'selected' : '' ?>>Tahun Ini</option>
                    <option value="custom" class="bg-gray-900 text-white" <?= $periode == 'custom' ? 'selected' : '' ?>>Custom Range...</option>
                </select>
            </div>
            <div id="customDateRange" class="<?= $periode == 'custom' ? '' : 'hidden' ?> md:col-span-2 grid grid-cols-2 gap-3 transition-all">
                <input type="date" id="tglMulai" value="<?= $tglMulai ?>" class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 px-6 text-white focus:border-emerald-500/50">
                <input type="date" id="tglAkhir" value="<?= $tglAkhir ?>" class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 px-6 text-white focus:border-emerald-500/50">
            </div>
            <div>
                <select id="typeFilter" class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 px-6 text-white focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 appearance-none cursor-pointer">
                    <option value="0" class="bg-gray-900 text-white" <?= $tipeFile == '0' ? 'selected' : '' ?>>Semua Tipe File</option>
                    <option value="pdf" class="bg-gray-900 text-white" <?= $tipeFile == 'pdf' ? 'selected' : '' ?>>PDF</option>
                    <option value="word" class="bg-gray-900 text-white" <?= $tipeFile == 'word' ? 'selected' : '' ?>>Word (.doc, .docx)</option>
                    <option value="excel" class="bg-gray-900 text-white" <?= $tipeFile == 'excel' ? 'selected' : '' ?>>Excel (.xls, .xlsx)</option>
                    <option value="powerpoint" class="bg-gray-900 text-white" <?= $tipeFile == 'powerpoint' ? 'selected' : '' ?>>PowerPoint (.ppt, .pptx)</option>
                    <option value="image" class="bg-gray-900 text-white" <?= $tipeFile == 'image' ? 'selected' : '' ?>>Gambar / Foto</option>
                    <option value="archive" class="bg-gray-900 text-white" <?= $tipeFile == 'archive' ? 'selected' : '' ?>>Arsip (.zip, .rar)</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Data Table Container -->
    <div class="rounded-[2.5rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl overflow-hidden">
        <form id="bulkDeleteForm" action="hapus_masal" method="POST">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse" id="arsipTable">
                    <thead class="bg-black/20 text-emerald-400/50 uppercase text-[10px] font-black tracking-widest whitespace-nowrap">
                        <tr>
                            <th class="px-6 py-5 text-center w-16">
                                <input type="checkbox" id="checkAll" class="rounded border-white/10 bg-white/5 text-emerald-500 focus:ring-emerald-500/50">
                            </th>
                            <th class="px-6 py-5">Dokumen / Nama File</th>
                            <th class="px-6 py-5">Kategori</th>
                            <th class="px-6 py-5">Tgl Arsip</th>
                            <th class="px-6 py-5">Ukuran</th>
                            <th class="px-6 py-5 text-right w-40">Tindakan</th>
                        </tr>
                    </thead>
                    <tbody id="arsipTableBody" class="divide-y divide-white/5" data-total="<?= number_format($totalData) ?>">
<?php endif; // End AJAX Header Check ?>
                        <?php if ($result && $result->num_rows > 0): // Changed $arsipList to $result ?>
                            <?php while ($row = $result->fetch_assoc()): ?>
                            <tr class="hover:bg-white/5 transition-all group">
                                <td class="px-6 py-6">
                                    <input type="checkbox" name="ids[]" value="<?= $row['id'] ?>" class="itemCheckbox rounded border-white/10 bg-black/50 text-emerald-500 focus:ring-emerald-500 cursor-pointer">
                                </td>
                                <td class="px-6 py-6">
                                    <div class="flex items-center gap-3">
                                        <?php
                                        $fileExt = strtolower(pathinfo($row['nama_file'], PATHINFO_EXTENSION));
                                        $iconClass = 'fa-file-alt';
                                        $colorClass = 'bg-gray-500/20 text-gray-400';
                                        
                                        if ($fileExt == 'pdf' || strpos($row['tipe_file'], 'pdf') !== false) {
                                            $iconClass = 'fa-file-pdf';
                                            $colorClass = 'bg-red-500/20 text-red-500';
                                        } elseif (in_array($fileExt, ['jpg', 'jpeg', 'png', 'webp', 'gif']) || strpos($row['tipe_file'], 'image') !== false) {
                                            $iconClass = 'fa-file-image';
                                            $colorClass = 'bg-blue-400/20 text-blue-400';
                                        } elseif (in_array($fileExt, ['doc', 'docx'])) {
                                            $iconClass = 'fa-file-word';
                                            $colorClass = 'bg-blue-600/20 text-blue-500';
                                        } elseif (in_array($fileExt, ['xls', 'xlsx'])) {
                                            $iconClass = 'fa-file-excel';
                                            $colorClass = 'bg-emerald-500/20 text-emerald-500';
                                        } elseif (in_array($fileExt, ['ppt', 'pptx'])) {
                                            $iconClass = 'fa-file-powerpoint';
                                            $colorClass = 'bg-orange-500/20 text-orange-500';
                                        } elseif (in_array($fileExt, ['zip', 'rar'])) {
                                            $iconClass = 'fa-file-archive';
                                            $colorClass = 'bg-yellow-500/20 text-yellow-500';
                                        }
                                        ?>
                                        <div class="h-10 w-10 flex items-center justify-center rounded-xl <?= $colorClass ?> shadow-inner">
                                            <i class="fas <?= $iconClass ?> text-lg"></i>
                                        </div>
                                        <div>
                                            <p class="font-bold text-white leading-tight group-hover:text-emerald-400 transition-colors"><?= sanitize($row['nama_arsip']) ?></p>
                                            <p class="text-[10px] text-white/30 truncate w-48"><?= sanitize($row['nama_file']) ?> • <span class="text-white/20 uppercase"><?= sanitize($row['nomor_surat'] ?: '-') ?></span></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-6 transition-all group-hover:pl-8">
                                    <span class="rounded-full bg-emerald-500/10 px-3 py-1 text-[10px] font-black text-emerald-400 border border-emerald-500/10 uppercase italic tracking-widest">
                                        <?= sanitize($row['nama_kategori']) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-6 text-xs text-white/50 font-bold uppercase tracking-tighter">
                                    <?= date('d M Y', strtotime($row['tanggal_arsip'])) ?>
                                </td>
                                <td class="px-6 py-6 text-xs text-white/30 font-medium">
                                    <?= formatFileSize($row['ukuran_file']) ?>
                                </td>
                                <td class="px-6 py-6 text-right">
                                    <div class="flex justify-end gap-2">
                                        <?php if ($row['gdrive_view_link']): ?>
                                        <button type="button" onclick="previewFile('<?= sanitize($row['gdrive_view_link']) ?>', '<?= sanitize($row['nama_arsip']) ?>')" 
                                            class="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-teal-500/5 text-teal-400 hover:bg-teal-500 hover:text-white transition-all shadow-lg border border-teal-500/10" title="Lihat Preview">
                                            <i class="fas fa-eye text-xs"></i>
                                        </button>
                                        <?php endif; ?>
                                        <a href="edit-arsip?id=<?= $row['id'] ?>" class="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-blue-500/5 text-blue-400 hover:bg-blue-500 hover:text-white transition-all shadow-lg border border-blue-500/10" title="Edit">
                                            <i class="fas fa-edit text-xs"></i>
                                        </a>
                                        <button type="button" onclick="confirmDelete(<?= $row['id'] ?>, '<?= addslashes($row['nama_arsip']) ?>')" 
                                            class="inline-flex h-9 w-9 items-center justify-center rounded-lg bg-red-500/5 text-red-500/50 hover:bg-red-500 hover:text-white transition-all shadow-lg border border-red-500/10">
                                            <i class="fas fa-trash text-xs"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" class="px-8 py-20 text-center italic text-white/20">Data tidak ditemukan...</td></tr>
                        <?php endif; ?>
<?php if ($isAjax) exit; // Stop execution if AJAX ?>
                    </tbody>
                </table>
            </div>
        </form>
    </div>

    <!-- Bulk Action Bar -->
     <div id="bulkBar" class="hidden fixed bottom-10 left-1/2 -translate-x-1/2 z-[100] px-8 py-4 rounded-3xl border border-white/20 bg-black/80 backdrop-blur-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex items-center gap-8 border-t-emerald-500/50 border-t-2">
        <p class="text-sm font-black text-white px-2 uppercase tracking-[0.2em]"><span id="selectedCount" class="text-emerald-400">0</span> terpilih</p>
        <div class="h-6 w-px bg-white/20"></div>
        <button type="button" onclick="submitBulkDelete()" class="group flex items-center gap-3 text-red-400 hover:text-red-300 font-black text-xs uppercase tracking-widest transition-all">
            <i class="fas fa-trash-alt group-hover:scale-110"></i> <span>Hapus Masal</span>
        </button>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div class="flex justify-center gap-2 pt-4">
        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
        <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&kategori=<?= $kategori ?>&periode=<?= $periode ?>&tgl_mulai=<?= $tglMulai ?>&tgl_akhir=<?= $tglAkhir ?>" 
           class="h-10 w-10 flex items-center justify-center rounded-xl border <?= $i === $page ? 'bg-emerald-600 border-emerald-500 text-white font-black' : 'border-white/10 bg-white/5 text-white/50' ?>">
            <?= $i ?>
        </a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<!-- PREVIEW MODAL (CUSTOM STYLE - NO BOOTSTRAP REQUIRED) -->
<div id="previewModal" class="fixed inset-0 z-[99999] hidden p-4 sm:p-10 flex items-center justify-center bg-black/95 backdrop-blur-xl">
    <div class="flex flex-col w-full h-full max-w-6xl">
        <div class="flex items-center justify-between mb-4">
            <h3 id="previewTitle" class="text-xl font-black text-white uppercase tracking-widest truncate">Preview File</h3>
            <button onclick="closePreview()" class="h-12 w-12 flex items-center justify-center rounded-2xl bg-white/10 text-white hover:bg-red-500 transition-all shadow-xl">
                <i class="fas fa-times text-lg"></i>
            </button>
        </div>
        <div class="flex-grow rounded-3xl border border-white/10 bg-white/5 overflow-hidden shadow-2xl relative">
            <div id="previewLoading" class="absolute inset-0 flex items-center justify-center bg-black/40 z-10">
                <div class="h-10 w-10 border-4 border-emerald-500/20 border-t-emerald-500 rounded-full animate-spin"></div>
            </div>
            <iframe id="previewFrame" src="" class="w-full h-full border-none" onload="document.getElementById('previewLoading').classList.add('hidden')"></iframe>
        </div>
    </div>
</div>

<!-- JS Hapus Masal & Live Search & Preview -->
<script>
// --- LIVE SEARCH (AJAX) ---
const liveSearchInput = document.getElementById('liveSearchInput');
const categoryFilter = document.getElementById('categoryFilter');
const typeFilter = document.getElementById('typeFilter');
const periodeFilter = document.getElementById('periodeFilter');
const customDateRange = document.getElementById('customDateRange');
const tglMulai = document.getElementById('tglMulai');
const tglAkhir = document.getElementById('tglAkhir');
const searchSpinner = document.getElementById('searchSpinner');
const tableBody = document.getElementById('arsipTableBody');
const totalDataCount = document.getElementById('totalDataCount');
const btnPrintDraft = document.getElementById('btnPrintDraft');
let searchTimeout = null;

function performSearch() {
    searchSpinner.classList.remove('hidden');
    const qValue = liveSearchInput.value;
    const katValue = categoryFilter.value;
    const typeValue = typeFilter.value;
    const periodeValue = periodeFilter.value;
    const tglMulaiValue = tglMulai.value;
    const tglAkhirValue = tglAkhir.value;
    
    // Toggle UI custom date range
    if (periodeValue === 'custom') {
        customDateRange.classList.remove('hidden');
        if (!tglMulaiValue || !tglAkhirValue) {
            searchSpinner.classList.add('hidden');
            return; // Tunggu user isi tanggal
        }
    } else {
        customDateRange.classList.add('hidden');
    }
    
    fetch(`arsip.php?q=${encodeURIComponent(qValue)}&kategori=${katValue}&tipe=${typeValue}&periode=${periodeValue}&tgl_mulai=${tglMulaiValue}&tgl_akhir=${tglAkhirValue}&ajax=1`)
        .then(response => response.text())
        .then(html => {
            tableBody.innerHTML = html;
            searchSpinner.classList.add('hidden');
            
            // Update the total count from data-total attribute in returned tbody
            const newTotal = tableBody.getAttribute('data-total') || '0';
            totalDataCount.innerText = newTotal;
            
            // Update URL print
            btnPrintDraft.href = `cetak?q=${encodeURIComponent(qValue)}&kategori=${katValue}&tipe=${typeValue}&periode=${periodeValue}&tgl_mulai=${tglMulaiValue}&tgl_akhir=${tglAkhirValue}`;

            rebindCheckboxes();
        })
        .catch(error => {
            console.error('Error fetching search results:', error);
            searchSpinner.classList.add('hidden');
        });
}

liveSearchInput.addEventListener('input', function() {
    clearTimeout(searchTimeout);
    searchSpinner.classList.remove('hidden');
    searchTimeout = setTimeout(performSearch, 300);
});

categoryFilter.addEventListener('change', performSearch);
typeFilter.addEventListener('change', performSearch);
periodeFilter.addEventListener('change', performSearch);
tglMulai.addEventListener('change', performSearch);
tglAkhir.addEventListener('change', performSearch);

function rebindCheckboxes() {
    const newItemCheckboxes = document.querySelectorAll('.itemCheckbox');
    newItemCheckboxes.forEach(cb => cb.addEventListener('change', toggleBulkBar));
}

// --- PREVIEW ---
function previewFile(url, title) {
    document.getElementById('previewTitle').textContent = title;
    // Ubah link view drive supaya bisa di-iframe (preview only)
    const previewUrl = url.replace('/view', '/preview');
    document.getElementById('previewFrame').src = previewUrl;
    document.getElementById('previewModal').classList.remove('hidden');
    document.getElementById('previewModal').classList.add('flex');
    document.getElementById('previewLoading').classList.remove('hidden');
}

function closePreview() {
    document.getElementById('previewModal').classList.add('hidden');
    document.getElementById('previewModal').classList.remove('flex');
    document.getElementById('previewFrame').src = '';
}

// --- BULK ACTION ---
const checkAll = document.getElementById('checkAll');
const itemCheckboxes = document.querySelectorAll('.itemCheckbox');
const bulkBar = document.getElementById('bulkBar');
const selectedCount = document.getElementById('selectedCount');

function toggleBulkBar() {
    const checked = Array.from(itemCheckboxes).filter(cb => cb.checked);
    selectedCount.textContent = checked.length;
    if (checked.length > 0) {
        bulkBar.classList.remove('hidden');
    } else {
        bulkBar.classList.add('hidden');
    }
}

if (checkAll) {
    checkAll.addEventListener('change', function() {
        itemCheckboxes.forEach(cb => cb.checked = this.checked);
        toggleBulkBar();
    });
}
itemCheckboxes.forEach(cb => cb.addEventListener('change', toggleBulkBar));

function submitBulkDelete() {
    if (confirm('Yakin ingin menghapus semua arsip yang dipilih?')) {
        document.getElementById('bulkDeleteForm').submit();
    }
}

// --- CONFIRM SINGLE DELETE ---
function confirmDelete(id, name) {
    if (confirm(`Hapus arsip "${name}" secara permanen?`)) {
        window.location.href = `arsip?hapus=${id}`;
    }
}
</script>

<?php 
if (!$isAjax) {
    require_once __DIR__ . '/templates/footer.php'; 
}
?>

