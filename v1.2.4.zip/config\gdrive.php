<?php
/**
 * ============================================================
 * GOOGLE DRIVE UPLOADER — Service Account + JWT + cURL
 * ============================================================
 * TANPA COMPOSER — Murni PHP Native
 * ============================================================
 *
 * LANGKAH SETUP:
 * 1. Buka Google Cloud Console → IAM & Admin → Service Accounts
 * 2. Download file JSON key Service Account Anda
 * 3. Buka file JSON tersebut, lalu tempelkan ISI LENGKAPNYA
 *    ke variabel $serviceAccountJson di bawah ini
 * 4. Pastikan folder Google Drive target sudah di-share ke
 *    email Service Account Anda (client_email di JSON)
 * ============================================================
 */

// Baca Konfigurasi OAuth2
$configPath = __DIR__ . '/gdrive-auth.json';

if (!file_exists($configPath)) {
    die("❌ Error: File <b>config/gdrive-auth.json</b> tidak ditemukan! Pastikan file tersebut ada di folder config.");
}

$gauth = json_decode(file_get_contents($configPath), true);

if (empty($gauth['refresh_token'])) {
    die("❌ Error: <b>Refresh Token Kosong!</b> Akses dulu halaman <a href='auth-callback.php'>auth-callback.php</a> untuk aktivasi.");
}

// ============================================================
// GOOGLE DRIVE CLASS (OAuth2 Version)
// ============================================================
class GoogleDriveUploader {
    
    private string $clientId;
    private string $clientSecret;
    private string $refreshToken;
    private string $folderId;
    private ?string $accessToken = null;
    
    public function __construct(array $gauth, string $folderId) {
        $this->clientId     = $gauth['client_id'] ?? '';
        $this->clientSecret = $gauth['client_secret'] ?? '';
        $this->refreshToken = $gauth['refresh_token'] ?? '';
        $this->folderId     = $folderId;
        
        if (empty($this->refreshToken)) {
            throw new Exception("❌ Refresh Token belum ada. Silakan jalankan auth-callback.php.");
        }
    }
    
    /**
     * Dapatkan Access Token baru menggunakan Refresh Token
     */
    private function getAccessToken(): string {
        if ($this->accessToken) {
            return $this->accessToken;
        }
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => 'https://oauth2.googleapis.com/token',
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POSTFIELDS     => http_build_query([
                'client_id'     => $this->clientId,
                'client_secret' => $this->clientSecret,
                'refresh_token' => $this->refreshToken,
                'grant_type'    => 'refresh_token'
            ])
        ]);
        
        $response = curl_exec($ch);
        $data = json_decode($response, true);
        curl_close($ch);
        
        if (isset($data['access_token'])) {
            $this->accessToken = $data['access_token'];
            return $this->accessToken;
        }
        
        throw new Exception("❌ Gagal Refresh Access Token: " . ($data['error_description'] ?? $response));
    }
    
    /**
     * Cari atau Buat Folder Kategori di dalam Master Folder
     */
    private function getOrCreateFolder(string $folderName): string {
        $accessToken = $this->getAccessToken();
        $folderNameEscaped = str_replace("'", "\\'", $folderName);
        
        // 1. Cari apakah folder sudah ada
        $query = "name = '$folderNameEscaped' and mimeType = 'application/vnd.google-apps.folder' and '{$this->folderId}' in parents and trashed = false";
        $url = "https://www.googleapis.com/drive/v3/files?" . http_build_query([
            'q' => $query,
            'fields' => 'files(id, name)',
            'supportsAllDrives' => 'true',
            'includeItemsFromAllDrives' => 'true'
        ]);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => ["Authorization: Bearer $accessToken"]
        ]);
        $response = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        if (!empty($response['files'][0]['id'])) {
            return $response['files'][0]['id'];
        }
        
        // 2. Jika tidak ada, buat baru
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => 'https://www.googleapis.com/drive/v3/files?supportsAllDrives=true',
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer $accessToken",
                "Content-Type: application/json"
            ],
            CURLOPT_POSTFIELDS => json_encode([
                'name'     => $folderName,
                'mimeType' => 'application/vnd.google-apps.folder',
                'parents'  => [$this->folderId]
            ])
        ]);
        $data = json_decode(curl_exec($ch), true);
        curl_close($ch);
        
        return $data['id'] ?? $this->folderId;
    }

    /**
     * Upload file ke Google Drive (Dengan Subfolder Kategori)
     */
    public function upload(string $filePath, string $fileName, string $mimeType, string $categoryName = ''): array {
        $accessToken = $this->getAccessToken();
        
        // Tentukan Folder Tujuan (Kategori atau Master)
        $targetFolderId = $this->folderId;
        if (!empty($categoryName)) {
            $targetFolderId = $this->getOrCreateFolder($categoryName);
        }
        
        if (!file_exists($filePath)) {
            throw new Exception("❌ File lokal tidak ditemukan: $filePath");
        }
        
        $metadata = json_encode([
            'name'    => $fileName,
            'parents' => [$targetFolderId]
        ]);
        
        $fileContent = file_get_contents($filePath);
        $boundary = '-------' . uniqid();
        
        $body  = "--$boundary\r\n";
        $body .= "Content-Type: application/json; charset=UTF-8\r\n\r\n";
        $body .= "$metadata\r\n";
        $body .= "--$boundary\r\n";
        $body .= "Content-Type: $mimeType\r\n\r\n";
        $body .= "$fileContent\r\n";
        $body .= "--$boundary--";
        
        $ch = curl_init();
        $apiUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink&supportsAllDrives=true';
        
        curl_setopt_array($ch, [
            CURLOPT_URL            => $apiUrl,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                "Authorization: Bearer $accessToken",
                "Content-Type: multipart/related; boundary=$boundary",
                "Content-Length: " . strlen($body)
            ]
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        $data = json_decode($response, true);
        if ($httpCode !== 200) {
            $errorDetail = $data['error']['message'] ?? $response;
            throw new Exception("❌ Gagal upload (HTTP $httpCode): $errorDetail");
        }
        
        $this->setPublicPermission($data['id']);
        
        return [
            'file_id'   => $data['id'],
            'view_link' => $data['webViewLink'] ?? "https://drive.google.com/file/d/{$data['id']}/view"
        ];
    }
    
    /**
     * Set file publik agar bisa dilihat linknya
     */
    private function setPublicPermission(string $fileId): void {
        $accessToken = $this->getAccessToken();
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => "https://www.googleapis.com/drive/v3/files/$fileId/permissions?supportsAllDrives=true",
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => [
                "Authorization: Bearer $accessToken",
                "Content-Type: application/json"
            ],
            CURLOPT_POSTFIELDS => json_encode([
                'role' => 'reader',
                'type' => 'anyone'
            ])
        ]);
        curl_exec($ch);
        curl_close($ch);
    }

    public function delete(string $fileId): bool {
        $accessToken = $this->getAccessToken();
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => "https://www.googleapis.com/drive/v3/files/$fileId?supportsAllDrives=true",
            CURLOPT_CUSTOMREQUEST  => 'DELETE',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => ["Authorization: Bearer $accessToken"]
        ]);
        curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $httpCode === 204;
    }
}

// ============================================================
// FUNGSI HELPER GOOGLE DRIVE
// ============================================================

function getGDriveUploader(): GoogleDriveUploader {
    global $gauth;
    return new GoogleDriveUploader($gauth, GDRIVE_FOLDER_ID);
}

function uploadToGDrive(string $filePath, string $fileName, string $mimeType, string $categoryName = ''): array {
    $uploader = getGDriveUploader();
    return $uploader->upload($filePath, $fileName, $mimeType, $categoryName);
}

function deleteFromGDrive(string $fileId): bool {
    $uploader = getGDriveUploader();
    return $uploader->delete($fileId);
}
