
            <!-- FOOTER DEVELOPER -->
            <footer class="mt-8 mb-4 border-t border-emerald-500/10 pt-6 text-center">
                <p class="text-[13px] font-medium text-emerald-400/80">
                    &copy; 2026 E-Arsip Madrasah. All Rights Reserved.
                </p>
                <p class="mt-1 text-xs text-emerald-500/50">
                    Designed by <a href="https://admin.mtssmaarif02kotagajah.my.id" target="_blank" class="font-bold text-emerald-400 hover:text-emerald-300 transition-colors underline underline-offset-2">Tumenggung Danang Triharto</a>
                </p>
            </footer>

        </div><!-- /.content-area -->
    </main>
</div><!-- /.admin-layout -->

<script>
// Toggle sidebar (mobile)
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebarOverlay').classList.toggle('active');
}

// Close sidebar when pressing Escape
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        document.getElementById('sidebar').classList.remove('open');
        document.getElementById('sidebarOverlay').classList.remove('active');
    }
});

// Auto-hide flash messages after 5s
document.querySelectorAll('.alert').forEach(function(alert) {
    setTimeout(function() {
        alert.style.opacity = '0';
        alert.style.transform = 'translateY(-10px)';
        setTimeout(function() { alert.remove(); }, 300);
    }, 5000);
});

// Auto-Trigger Pseudo Cron (Background, tanpa memblokir UI)
if (window.fetch) {
    setTimeout(() => {
        fetch('<?= BASE_URL ?>/cron/auto_backup.php').catch(e => {});
    }, 2000);
}
</script>

</body>
</html>
