<?php
/**
 * ============================================================
 * LOGIN PAGE — E-Arsip Digital MTs Ma'arif 02 Kotagajah
 * ============================================================
 */

require_once __DIR__ . '/../config/koneksi.php';

// Jika sudah login, redirect ke dashboard
if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/admin/dashboard');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $username = sanitize($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($username) || empty($password)) {
            $error = 'Username dan Password tidak boleh kosong!';
        } else {
            // Gunakan cara Tradisional (Tanpa get_result) agar kompatibel di semua hosting
            $usernameEsc = $koneksi->real_escape_string($username);
            $query = "SELECT * FROM users WHERE username = '$usernameEsc' LIMIT 1";
            $result = $koneksi->query($query);
            $user = $result->fetch_assoc();

            if ($user && password_verify($password, $user['password'])) {
                // Set Session
                $_SESSION['user_id']       = $user['id'];
                $_SESSION['user_nama']     = $user['nama'];
                $_SESSION['nama_lengkap']  = $user['nama'];
                $_SESSION['role']          = $user['role'];
                $_SESSION['username']      = $user['username'];

                // Catat Log
                logActivity('Login', 'Berhasil masuk ke sistem.');
                
                header('Location: ' . BASE_URL . '/admin/dashboard');
                exit;
            } else {
                $error = 'Username atau Password salah!';
            }
        }
    } catch (\Throwable $e) {
        die("❌ ERROR FATAL DIBONGKAR: " . $e->getMessage() . " di baris " . $e->getLine());
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk ke Sistem — <?= APP_NAME ?></title>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Tailwind CSS (Play CDN) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'ui-sans-serif', 'system-ui'],
                    },
                }
            }
        }
    </script>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css?v=<?= time() ?>">
</head>
<body class="bg-[#0c1a0b] text-slate-100 flex items-center justify-center min-h-screen p-4">

    <div class="w-full max-w-md bg-[#0f2a0d]/90 border border-emerald-500/20 rounded-[2rem] sm:p-10 p-6 shadow-2xl">
        <div class="mb-8 text-center">
            <div class="w-20 h-20 bg-emerald-500/20 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-emerald-500/30">
                <i class="fas fa-folder-open text-emerald-400 text-3xl"></i>
            </div>
            <h1 class="text-3xl font-black italic tracking-tight uppercase leading-none">E-Arsip <span class="text-emerald-400">Digital</span></h1>
            <p class="mt-2 text-emerald-400/50 font-medium text-xs uppercase tracking-widest leading-loose"><?= APP_FULL_NAME ?></p>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-500/10 border border-red-500/20 text-red-500 p-4 rounded-2xl mb-6 text-sm font-bold flex items-center gap-3">
                <i class="fas fa-exclamation-circle"></i> <?= $error ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST" class="space-y-6 text-left">
            <div>
                <label class="text-[10px] font-black uppercase tracking-widest text-emerald-400/50 ml-1">Username</label>
                <div class="relative mt-1">
                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-400/30">
                        <i class="fas fa-user text-sm"></i>
                    </span>
                    <input type="text" name="username" class="w-full bg-black/20 border border-emerald-500/10 focus:border-emerald-500 rounded-xl py-3 pl-11 pr-4 text-white outline-none" placeholder="Masukkan username" required autocomplete="off">
                </div>
            </div>

            <div>
                <label class="text-[10px] font-black uppercase tracking-widest text-emerald-400/50 ml-1">Password</label>
                <div class="relative mt-1">
                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-emerald-400/30">
                        <i class="fas fa-shield-halved text-sm"></i>
                    </span>
                    <input type="password" name="password" class="w-full bg-black/20 border border-emerald-500/10 focus:border-emerald-500 rounded-xl py-3 pl-11 pr-4 text-white outline-none" placeholder="Masukkan password" required>
                </div>
            </div>

            <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase tracking-[0.2em] py-4 rounded-2xl border-0 mt-4 cursor-pointer">
                Masuk ke Sistem
            </button>
        </form>

        <div class="mt-10 pt-8 border-t border-white/5">
            <p class="text-[10px] font-bold text-white/20 uppercase tracking-[0.3em]">
                &copy; 2026 <?= APP_FULL_NAME ?>
            </p>
        </div>
    </div>

</body>
</html>
