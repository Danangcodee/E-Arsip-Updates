<?php
/**
 * ============================================================
 * PROFIL SAYA — Ganti Username & Password + Upload Foto
 * ============================================================
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
requireLogin();

$userId = (int) $_SESSION['user_id'];
$pageTitle    = 'Profil Saya';
$pageSubtitle = 'Kelola keamanan akun Anda';
$activePage   = 'profile';

// Ambil data user terbaru
$stmt = $koneksi->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param('i', $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $passBaru = $_POST['password_baru'] ?? '';
    $fotoBlob = $_POST['foto_blob'] ?? '';
    
    // 0. Proses Foto jika ada blob (hasil crop)
    if (!empty($fotoBlob)) {
        $imgData = explode(',', $fotoBlob);
        if (count($imgData) > 1) {
            $blob = base64_decode($imgData[1]);
            $fileName = 'profile_' . $userId . '_' . time() . '.jpg';
            $targetDir = __DIR__ . '/../assets/img/profile/';
            if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
            
            // Hapus foto lama jika ada
            if ($user['foto'] && file_exists($targetDir . $user['foto'])) {
                @unlink($targetDir . $user['foto']);
            }
            
            file_put_contents($targetDir . $fileName, $blob);
            $upFoto = $koneksi->prepare("UPDATE users SET foto = ? WHERE id = ?");
            $upFoto->bind_param('si', $fileName, $userId);
            $upFoto->execute();
            $upFoto->close();
        }
    }

    // 1. Update Nama & Username
    if (!empty($nama) && !empty($username)) {
        try {
            $up = $koneksi->prepare("UPDATE users SET nama = ?, username = ? WHERE id = ?");
            $up->bind_param('ssi', $nama, $username, $userId);
            if ($up->execute()) {
                $_SESSION['user_nama'] = $nama; 
                setFlash('success', 'Profil berhasil diperbarui. ✅');
            } else {
                setFlash('error', 'Gagal memperbarui profil.');
            }
            $up->close();
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) {
                setFlash('error', 'Username "' . sanitize($username) . '" sudah dipakai orang lain! ❌');
            } else {
                setFlash('error', 'Kesalahan Sistem: ' . $e->getMessage());
            }
        }
    }
    
    // 2. Jika isi password baru
    if (!empty($passBaru)) {
        $hashed = password_hash($passBaru, PASSWORD_DEFAULT);
        $upPass = $koneksi->prepare("UPDATE users SET password = ? WHERE id = ?");
        $upPass->bind_param('si', $hashed, $userId);
        $upPass->execute();
        $upPass->close();
        setFlash('success', 'Profil dan Password berhasil diperbarui! 🔐');
    }
    
    header('Location: profile');
    exit;
}

require_once __DIR__ . '/templates/header.php';
?>

<!-- Cropper JS & CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>

<div class="p-4 sm:p-6 lg:p-8">
    <div class="mb-8 px-2 text-center sm:text-left">
        <h1 class="text-3xl font-black tracking-tight text-white italic lowercase tracking-widest"><i class="fas fa-fingerprint text-emerald-500 mr-2"></i>Keamanan <span class="text-emerald-400 uppercase">Akun</span></h1>
        <p class="mt-2 text-emerald-400/60 font-medium">Pastikan password Anda kuat dan sulit ditebak.</p>
    </div>

    <div class="max-w-4xl grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- Photo Sidebar -->
        <div class="lg:col-span-1 space-y-6">
            <div class="rounded-[2.5rem] border border-white/10 bg-white/5 p-8 text-center backdrop-blur-xl">
                <div class="relative group mx-auto w-48 h-48 mb-6">
                    <div class="w-full h-full rounded-[2.5rem] overflow-hidden border-4 border-white/10 shadow-2xl bg-black/50">
                        <?php if ($user['foto']): ?>
                            <img id="currentAvatar" src="<?= BASE_URL ?>/assets/img/profile/<?= $user['foto'] ?>" class="w-full h-full object-cover">
                        <?php else: ?>
                            <div id="avatarPlaceholder" class="w-full h-full flex items-center justify-center text-5xl font-black text-white/10 bg-gradient-to-br from-emerald-500/10 to-transparent">
                                <?= strtoupper(substr($user['nama'],0,2)) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <!-- Overlay Upload -->
                    <label for="inputFoto" class="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-all cursor-pointer rounded-[2.5rem] backdrop-blur-sm">
                        <div class="text-center">
                            <i class="fas fa-camera text-2xl text-white mb-2"></i>
                            <p class="text-[10px] font-black uppercase text-white tracking-widest">Ganti Foto</p>
                        </div>
                    </label>
                    <input type="file" id="inputFoto" class="hidden" accept="image/*">
                </div>
                <h2 class="text-xl font-black text-white"><?= sanitize($user['nama']) ?></h2>
                <p class="text-xs font-bold text-emerald-400/50 uppercase tracking-widest mt-1"><?= $user['role'] ?></p>
            </div>
        </div>

        <!-- Form Area -->
        <div class="lg:col-span-2">
            <div class="rounded-[2.5rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl">
                <div class="rounded-[2.25rem] bg-gradient-to-br from-white/10 to-transparent p-8 sm:p-12">
                    <form id="profileForm" method="POST" action="" class="space-y-8">
                        <input type="hidden" name="foto_blob" id="fotoBlob">
                        
                        <div class="space-y-6">
                            <!-- Nama -->
                            <div class="space-y-2">
                                <label class="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400/50 ml-4 block">Nama Lengkap Anda</label>
                                <div class="relative">
                                    <span class="absolute left-6 top-1/2 -translate-y-1/2 text-emerald-400/30"><i class="fas fa-id-card"></i></span>
                                    <input type="text" name="nama" required value="<?= sanitize($user['nama']) ?>"
                                        class="w-full rounded-2xl border border-white/10 bg-black/30 py-4 pl-14 pr-6 text-white focus:border-emerald-500/50 focus:outline-none placeholder-white/10">
                                </div>
                            </div>

                            <!-- Username -->
                            <div class="space-y-2">
                                <label class="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400/50 ml-4 block">Username Login</label>
                                <div class="relative">
                                    <span class="absolute left-6 top-1/2 -translate-y-1/2 text-emerald-400/30"><i class="fas fa-at"></i></span>
                                    <input type="text" name="username" required value="<?= sanitize($user['username']) ?>"
                                        class="w-full rounded-2xl border border-white/10 bg-black/30 py-4 pl-14 pr-6 text-white focus:border-emerald-500/50 focus:outline-none placeholder-white/10">
                                </div>
                            </div>

                            <div class="h-px bg-white/5 mx-4"></div>

                            <!-- Password Baru -->
                            <div class="space-y-2">
                                <label class="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400/50 ml-4 block">Password Baru (Opsional)</label>
                                <div class="relative">
                                    <span class="absolute left-6 top-1/2 -translate-y-1/2 text-emerald-400/30"><i class="fas fa-key"></i></span>
                                    <input type="password" name="password_baru" placeholder="Kosongkan jika tidak ganti password"
                                        class="w-full rounded-2xl border border-white/10 bg-black/30 py-4 pl-14 pr-6 text-white focus:border-emerald-500/50 focus:outline-none placeholder-white/10">
                                </div>
                                <p class="text-[10px] text-emerald-400/40 ml-4 italic">*Gunakan minimal 8 karakter kombinasi huruf dan angka.</p>
                            </div>
                        </div>

                        <div class="pt-4">
                            <button type="submit" class="w-full rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 py-5 font-black uppercase tracking-[0.3em] text-white transition-all hover:shadow-2xl hover:shadow-emerald-500/30 active:scale-95">
                                <i class="fas fa-save mr-2"></i> Update Profil
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Crop -->
<div id="modalCrop" class="fixed inset-0 z-[10000] hidden items-center justify-center p-4 bg-black/95 backdrop-blur-xl">
    <div class="w-full max-w-lg bg-slate-900 rounded-[2.5rem] overflow-hidden border border-white/10 shadow-3xl">
        <div class="p-6 border-b border-white/5 flex justify-between items-center">
            <h3 class="text-lg font-black text-white uppercase tracking-widest">Atur Foto Profil</h3>
            <button onclick="closeCropModal()" class="text-white/50 hover:text-white"><i class="fas fa-times"></i></button>
        </div>
        <div class="p-6">
            <div class="aspect-square w-full overflow-hidden rounded-2xl bg-black/50">
                <img id="imageToCrop" class="max-w-full">
            </div>
        </div>
        <div class="p-6 bg-black/20 flex gap-3">
            <button onclick="closeCropModal()" class="flex-1 py-4 font-bold text-white/50 hover:text-white transition-colors">Batal</button>
            <button id="btnCrop" class="flex-1 py-4 rounded-2xl bg-emerald-600 font-bold text-white hover:bg-emerald-500 transition-all">Simpan Potongan</button>
        </div>
    </div>
</div>

<script>
    let cropper;
    const inputFoto = document.getElementById('inputFoto');
    const modalCrop = document.getElementById('modalCrop');
    const imageToCrop = document.getElementById('imageToCrop');
    const fotoBlob = document.getElementById('fotoBlob');

    inputFoto.addEventListener('change', function(e) {
        const files = e.target.files;
        if (files && files.length > 0) {
            const reader = new FileReader();
            reader.onload = function(event) {
                imageToCrop.src = event.target.result;
                modalCrop.classList.remove('hidden');
                modalCrop.classList.add('flex');
                
                if (cropper) cropper.destroy();
                cropper = new Cropper(imageToCrop, {
                    aspectRatio: 1,
                    viewMode: 1,
                    background: false,
                    responsive: true,
                    autoCropArea: 1
                });
            };
            reader.readAsDataURL(files[0]);
        }
    });

    document.getElementById('btnCrop').addEventListener('click', function() {
        const canvas = cropper.getCroppedCanvas({
            width: 500,
            height: 500
        });
        
        const base64 = canvas.toDataURL('image/jpeg');
        fotoBlob.value = base64;
        
        // Ganti preview sementara di halaman
        const currentAvatar = document.getElementById('currentAvatar');
        const placeholder = document.getElementById('avatarPlaceholder');
        
        if (currentAvatar) currentAvatar.src = base64;
        if (placeholder) {
            placeholder.outerHTML = `<img id="currentAvatar" src="${base64}" class="w-full h-full object-cover">`;
        }
        
        closeCropModal();
    });

    function closeCropModal() {
        modalCrop.classList.add('hidden');
        modalCrop.classList.remove('flex');
        inputFoto.value = '';
        if (cropper) cropper.destroy();
    }
</script>

<?php require_once __DIR__ . '/templates/footer.php'; ?>

