<?php
/**
 * ============================================================
 * RIWAYAT AKTIVITAS — E-Arsip Digital MTs Ma'arif 02 Kotagajah
 * ============================================================
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
requireLogin();

// Riwayat sekarang dapat diakses oleh Admin & Operator

$pageTitle    = 'Riwayat Aktivitas';
$pageSubtitle = 'Pantau semua log aktivitas pengguna di sistem';
$activePage   = 'riwayat';

// Pagination
$page     = max(1, (int) ($_GET['page'] ?? 1));
$perPage  = 30;
$offset   = ($page - 1) * $perPage;

// Filter
$search   = trim($_GET['q'] ?? '');
$userFilter = (int) ($_GET['user'] ?? 0);

$where  = "WHERE 1=1";
$params = [];
$types  = '';

if ($search) {
    $where .= " AND (l.action LIKE ? OR l.details LIKE ? OR l.ip_address LIKE ?)";
    $searchParam = "%$search%";
    $params[] = &$searchParam; $params[] = &$searchParam; $params[] = &$searchParam;
    $types .= 'sss';
}
if ($userFilter > 0) {
    $where .= " AND l.user_id = ?";
    $params[] = &$userFilter;
    $types .= 'i';
}

// Hitung Total Data
$countQuery = "SELECT COUNT(*) as total FROM activity_logs l $where";
$stmtCount = $koneksi->prepare($countQuery);
if ($types) $stmtCount->bind_param($types, ...$params);
$stmtCount->execute();
$totalData = $stmtCount->get_result()->fetch_assoc()['total'];
$stmtCount->close();
$totalPages = ceil($totalData / $perPage);

// Ambil Data Log
$query = "SELECT l.*, u.nama, u.role, u.username 
          FROM activity_logs l 
          JOIN users u ON l.user_id = u.id 
          $where 
          ORDER BY l.created_at DESC 
          LIMIT $perPage OFFSET $offset";

$stmtData = $koneksi->prepare($query);
if ($types) $stmtData->bind_param($types, ...$params);
$stmtData->execute();
$logs = $stmtData->get_result();
$stmtData->close();

$allUsers = $koneksi->query("SELECT id, nama FROM users ORDER BY nama ASC");

require_once __DIR__ . '/templates/header.php';
?>

<div class="p-4 sm:p-6 lg:p-8 space-y-8">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 class="text-3xl font-black tracking-tight text-white uppercase italic tracking-widest leading-none">Log <span class="text-emerald-400">Aktivitas</span></h1>
            <p class="mt-2 text-emerald-400/60 font-medium">Rekaman jejak digital penggunaan sistem e-arsip.</p>
        </div>
        <div class="flex gap-2">
            <div class="bg-white/5 border border-white/10 rounded-2xl px-6 py-3 text-center">
                <p class="text-[10px] font-black uppercase tracking-widest text-white/30 leading-none mb-1">Total Log</p>
                <p class="text-xl font-black text-white leading-none"><?= number_format($totalData) ?></p>
            </div>
        </div>
    </div>

    <!-- Filter Bar -->
    <div class="rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur-xl">
        <form method="GET" action="" class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div class="md:col-span-2 relative">
                <i class="fas fa-search absolute left-5 top-1/2 -translate-y-1/2 text-white/20"></i>
                <input type="text" name="q" placeholder="Cari aktivitas, detail, atau IP..." value="<?= sanitize($search) ?>"
                    class="w-full rounded-xl border border-white/10 bg-black/20 py-3 pl-12 pr-5 text-white placeholder-white/20 focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all text-sm">
            </div>
            <div>
                <select name="user" class="w-full rounded-xl border border-white/10 bg-black/20 py-3 px-5 text-white focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 appearance-none text-sm cursor-pointer">
                    <option value="0" class="bg-gray-900 text-white">Semua Pengguna</option>
                    <?php while ($u = $allUsers->fetch_assoc()): ?>
                    <option value="<?= $u['id'] ?>" <?= $userFilter == $u['id'] ? 'selected' : '' ?> class="bg-gray-900 text-white border-none"><?= sanitize($u['nama']) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <button type="submit" class="rounded-xl bg-white/5 border border-white/10 font-black uppercase tracking-widest text-xs text-white hover:bg-emerald-500 hover:border-emerald-400 transition-all active:scale-95">
                Terapkan Filter
            </button>
        </form>
    </div>

    <!-- Timeline Table -->
    <div class="rounded-[2.5rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl overflow-hidden">
        <div class="rounded-[2.25rem] bg-gradient-to-br from-white/10 to-transparent">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead class="bg-black/20 text-emerald-400/50 uppercase text-[10px] font-black tracking-widest">
                        <tr>
                            <th class="px-8 py-5">Waktu</th>
                            <th class="px-8 py-5">Pengguna</th>
                            <th class="px-8 py-5">Tindakan</th>
                            <th class="px-8 py-5">Keterangan / Detail</th>
                            <th class="px-8 py-5 text-right">Alamat IP</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-white/5">
                        <?php if ($logs->num_rows > 0): ?>
                            <?php while ($log = $logs->fetch_assoc()): 
                                $badgeClass = 'bg-blue-500/10 text-blue-400 border-blue-500/20';
                                $icon = 'fa-info-circle';
                                
                                if (strpos($log['action'], 'Hapus') !== false) {
                                    $badgeClass = 'bg-red-500/10 text-red-500 border-red-500/20';
                                    $icon = 'fa-trash-alt';
                                } elseif (strpos($log['action'], 'Upload') !== false || strpos($log['action'], 'Tambah') !== false) {
                                    $badgeClass = 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
                                    $icon = 'fa-plus-circle';
                                } elseif ($log['action'] === 'Login') {
                                    $badgeClass = 'bg-amber-500/10 text-amber-500 border-amber-500/20';
                                    $icon = 'fa-sign-in-alt';
                                }
                            ?>
                            <tr class="hover:bg-white/5 transition-all group">
                                <td class="px-8 py-6 whitespace-nowrap">
                                    <p class="text-xs font-black text-white leading-none mb-1 uppercase tracking-tighter">
                                        <?= date('H:i:s', strtotime($log['created_at'])) ?>
                                    </p>
                                    <p class="text-[10px] text-white/30 font-bold uppercase tracking-widest">
                                        <?= date('d M Y', strtotime($log['created_at'])) ?>
                                    </p>
                                </td>
                                <td class="px-8 py-6">
                                    <div class="flex items-center gap-3">
                                        <div class="h-8 w-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-[10px] font-black text-emerald-400">
                                            <?= strtoupper(substr($log['nama'], 0, 2)) ?>
                                        </div>
                                        <div>
                                            <p class="text-xs font-black text-white leading-none mb-1"><?= sanitize($log['nama']) ?></p>
                                            <p class="text-[9px] font-bold text-white/30 uppercase tracking-widest"><?= $log['role'] ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-8 py-6">
                                    <span class="inline-flex items-center gap-2 rounded-full px-3 py-1 text-[9px] font-black uppercase tracking-widest border <?= $badgeClass ?>">
                                        <i class="fas <?= $icon ?>"></i> <?= $log['action'] ?>
                                    </span>
                                </td>
                                <td class="px-8 py-6">
                                    <p class="text-xs text-white/70 italic font-medium">"<?= sanitize($log['details']) ?>"</p>
                                </td>
                                <td class="px-8 py-6 text-right">
                                    <code class="text-[10px] font-black px-3 py-1 rounded-lg bg-black/40 text-emerald-400/50 border border-emerald-400/10 tracking-widest">
                                        <?= $log['ip_address'] ?>
                                    </code>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="5" class="px-8 py-20 text-center italic text-white/20">Belum ada riwayat aktivitas tercatat...</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Pagination -->
    <?php if ($totalPages > 1): ?>
    <div class="flex justify-center gap-2 pt-4">
        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
        <a href="?page=<?= $i ?>&q=<?= urlencode($search) ?>&user=<?= $userFilter ?>" 
           class="h-10 w-10 flex items-center justify-center rounded-xl border <?= $i === $page ? 'bg-emerald-600 border-emerald-500 text-white font-black' : 'border-white/10 bg-white/5 text-white/50' ?> transition-all hover:bg-white/10 active:scale-95">
            <?= $i ?>
        </a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>

