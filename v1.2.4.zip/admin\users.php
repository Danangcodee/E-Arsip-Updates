<?php
/**
 * ============================================================
 * MANAJEMEN USER — E-Arsip Digital MTs Ma'arif 02 Kotagajah
 * ============================================================
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
requireLogin();

// Proteksi: Hanya admin yang boleh masuk
if (($_SESSION['role'] ?? '') !== 'admin') {
    setFlash('error', 'Anda tidak memiliki hak akses untuk halaman ini.');
    header('Location: ' . BASE_URL . '/admin/dashboard');
    exit;
}

$pageTitle    = 'Manajemen User';
$pageSubtitle = 'Kelola hak akses Administrator & Staf';
$activePage   = 'users';

// ============================================================
// PROSES TAMBAH USER
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'tambah') {
        $nama     = trim($_POST['nama'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $role     = $_POST['role'] ?? 'operator';
        
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $koneksi->prepare("INSERT INTO users (nama, username, password, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('ssss', $nama, $username, $hashed, $role);
        
        try {
            if ($stmt->execute()) {
                logActivity('Tambah User', "Membuat user baru: \"$nama\" ($role)");
                setFlash('success', "User \"$nama\" berhasil dibuat. ✅");
            } else {
                setFlash('error', 'Gagal membuat user.');
            }
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) {
                setFlash('error', 'Username "' . sanitize($username) . '" sudah digunakan oleh orang lain! ❌');
            } else {
                setFlash('error', 'Error Sistem: ' . $e->getMessage());
            }
        }
        $stmt->close();
        header('Location: users');
        exit;
    }
}

// ============================================================
// PROSES HAPUS USER
// ============================================================
if (isset($_GET['hapus']) && is_numeric($_GET['hapus'])) {
    $idHapus = (int) $_GET['hapus'];
    
    // Jangan biarkan hapus diri sendiri
    if ($idHapus === (int) $_SESSION['user_id']) {
        setFlash('error', 'Keamanan: Anda tidak bisa menghapus akun Anda sendiri saat sedang aktif! 🛡️');
    } else {
        // Ambil data user yang akan dihapus
        $stmt = $koneksi->prepare("SELECT nama, role FROM users WHERE id = ?");
        $stmt->bind_param('i', $idHapus);
        $stmt->execute();
        $targetUser = $stmt->get_result()->fetch_assoc();
        $namaHapus = $targetUser['nama'] ?? 'Unknown';
        $roleHapus = $targetUser['role'] ?? 'operator';
        $stmt->close();

        // Hitung total admin yang tersisa
        $res = $koneksi->query("SELECT COUNT(*) as total FROM users WHERE role = 'admin'");
        $totalAdmin = $res->fetch_assoc()['total'];

        if ($roleHapus === 'admin' && $totalAdmin <= 1) {
            setFlash('error', 'PERINGATAN: Tidak dapat menghapus satu-satunya Administrator yang tersisa! Sistem butuh minimal 1 Admin agar tidak terkunci. 🚨');
        } else {
            $stmt = $koneksi->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param('i', $idHapus);
            if ($stmt->execute()) {
                logActivity('Hapus User', "Menghapus user: \"$namaHapus\"");
                setFlash('success', "User \"$namaHapus\" berhasil dihapus. ✅");
            }
            $stmt->close();
        }
    }
    header('Location: users');
    exit;
}

$users = $koneksi->query("SELECT * FROM users ORDER BY role ASC, nama ASC");
require_once __DIR__ . '/templates/header.php';
?>

<div class="p-4 sm:p-6 lg:p-8 space-y-8">
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <h1 class="text-3xl font-black tracking-tight text-white">Kelola <span class="text-emerald-400">Pengguna</span></h1>
            <p class="mt-2 text-emerald-400/60 font-medium">Tambah atau atur hak akses petugas sistem.</p>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        <!-- Form Tambah -->
        <div class="rounded-[2rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl">
            <div class="rounded-[1.75rem] bg-gradient-to-br from-white/10 to-transparent p-6">
                <h2 class="mb-5 text-xl font-black uppercase tracking-widest text-emerald-300">➕ User Baru</h2>
                <form method="POST" action="" class="space-y-4">
                    <input type="hidden" name="action" value="tambah">
                    <div>
                        <label class="text-[10px] font-black uppercase tracking-widest text-emerald-400/50 ml-2 mb-1 block">Nama Lengkap</label>
                        <input type="text" name="nama" required class="w-full rounded-xl border border-white/10 bg-black/20 py-3 px-5 text-white focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10">
                    </div>
                    <div>
                        <label class="text-[10px] font-black uppercase tracking-widest text-emerald-400/50 ml-2 mb-1 block">Username</label>
                        <input type="text" name="username" required class="w-full rounded-xl border border-white/10 bg-black/20 py-3 px-5 text-white focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10">
                    </div>
                    <div>
                        <label class="text-[10px] font-black uppercase tracking-widest text-emerald-400/50 ml-2 mb-1 block">Password</label>
                        <input type="password" name="password" required class="w-full rounded-xl border border-white/10 bg-black/20 py-3 px-5 text-white focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10">
                    </div>
                    <div>
                        <label class="text-[10px] font-black uppercase tracking-widest text-emerald-400/50 ml-2 mb-1 block">Hak Akses</label>
                        <select name="role" required class="w-full rounded-xl border border-white/10 bg-black/20 py-3 px-5 text-white focus:border-emerald-500/50 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 appearance-none cursor-pointer">
                            <option value="operator" class="bg-gray-900 text-white">Staf Operator</option>
                            <option value="admin" class="bg-gray-900 text-white">Administrator</option>
                        </select>
                    </div>
                    <button type="submit" class="mt-2 w-full rounded-xl bg-emerald-600 py-4 font-black uppercase tracking-widest text-white transition-all hover:bg-emerald-500 active:scale-95 shadow-lg shadow-emerald-500/20">
                        Simpan Akun
                    </button>
                </form>
            </div>
        </div>

        <!-- Tabel User -->
        <div class="lg:col-span-2 rounded-[2.5rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl overflow-hidden">
            <div class="rounded-[2.25rem] bg-gradient-to-br from-white/10 to-transparent">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead class="bg-black/20 text-emerald-400/50 uppercase text-[10px] font-black tracking-widest">
                            <tr>
                                <th class="px-8 py-5">#</th>
                                <th class="px-8 py-5">Nama / Username</th>
                                <th class="px-8 py-5">Role</th>
                                <th class="px-8 py-5 text-right">Tindakan</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-white/5">
                            <?php 
                            $no = 1;
                            // Hitung jumlah admin dulu untuk logika tampilan
                            $resAdmin = $koneksi->query("SELECT COUNT(*) as total FROM users WHERE role = 'admin'");
                            $countAdmin = $resAdmin->fetch_assoc()['total'];

                            while ($u = $users->fetch_assoc()): 
                                // Cek apakah boleh dihapus dari sisi UI
                                $isSelf = ($u['id'] === (int)$_SESSION['user_id']);
                                $isLastAdmin = ($u['role'] === 'admin' && $countAdmin <= 1);
                                $canDeleteUI = !$isSelf && !$isLastAdmin;
                            ?>
                            <tr class="hover:bg-white/5 transition-all">
                                <td class="px-8 py-6 text-white/30 text-xs font-bold"><?= $no++ ?></td>
                                <td class="px-8 py-6 text-sm">
                                    <p class="font-bold text-white"><?= sanitize($u['nama']) ?></p>
                                    <p class="text-[10px] text-emerald-400/50 font-black tracking-widest uppercase">@<?= sanitize($u['username']) ?></p>
                                </td>
                                <td class="px-8 py-6">
                                    <span class="rounded-full px-4 py-1.5 text-[10px] font-black uppercase tracking-wider border <?= $u['role'] === 'admin' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 'bg-blue-500/10 text-blue-400 border-blue-500/20' ?>">
                                        <?= $u['role'] === 'admin' ? 'Administrator' : 'Staf Operator' ?>
                                    </span>
                                </td>
                                <td class="px-8 py-6 text-right">
                                    <?php if ($canDeleteUI): ?>
                                    <a href="?hapus=<?= $u['id'] ?>" class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-red-500/5 text-red-500/50 hover:bg-red-500 hover:text-white transition-all shadow-xl" onclick="return confirm('Hapus pengguna ini?')">
                                        <i class="fas fa-trash-alt text-xs"></i>
                                    </a>
                                    <?php else: ?>
                                        <div class="inline-flex items-center gap-2 text-[9px] font-black text-white/20 uppercase tracking-widest border border-white/5 px-4 py-2 rounded-xl">
                                            <i class="fas fa-shield-alt text-emerald-500/50"></i> Protected
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>

