<?php
/**
 * Application: E-Arsip Madrasah Digital
 * Developer: Tumenggung Danang Triharto
 * URL: https://admin.mtssmaarif02kotagajah.my.id
 * All Rights Reserved © 2026
 */
$pageTitle = "Pengaturan Sistem";
$activePage = "pengaturan";

require_once __DIR__ . '/../config/koneksi.php';
requireLogin();
if (($_SESSION['role'] ?? '') !== 'admin') {
    die("Akses Eksekutif Ditolak.");
}

// ---------------------------------------------------------
// PROSES PENYIMPANAN
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_start(); // Cegah error header jika ada output tak terduga
    
    // 1. Ambil Inputan User
    $new_app_name = trim($_POST['app_full_name'] ?? '');
    $new_city = trim($_POST['app_city'] ?? '');

    $new_bot_token = trim($_POST['telegram_bot_token'] ?? '');
    $new_chat_id = trim($_POST['telegram_chat_id'] ?? '');
    $new_telegram_backup = isset($_POST['telegram_backup']) && $_POST['telegram_backup'] === 'Y' ? 'Y' : 'N';
    $new_telegram_period = trim($_POST['telegram_backup_period'] ?? 'manual');
    $new_telegram_time = trim($_POST['telegram_backup_time'] ?? '00:00');
    
    $new_gdrive_client = trim($_POST['gdrive_client_id'] ?? '');
    $new_gdrive_secret = trim($_POST['gdrive_client_secret'] ?? '');

    // 2. TIMPA config/koneksi.php menggunakan Regex Replacement
    $koneksiPath = __DIR__ . '/../config/koneksi.php';
    if(file_exists($koneksiPath)){
        $content = file_get_contents($koneksiPath);
        
        $configs = [
            'APP_FULL_NAME' => $new_app_name,
            'APP_CITY'      => $new_city,
            'TELEGRAM_BOT_TOKEN' => $new_bot_token,
            'TELEGRAM_CHAT_ID'   => $new_chat_id,
            'TELEGRAM_BACKUP_DB' => $new_telegram_backup,
            'TELEGRAM_BACKUP_PERIOD' => $new_telegram_period,
            'TELEGRAM_BACKUP_TIME' => $new_telegram_time
        ];

        foreach($configs as $key => $val){
            $valEscaped = addslashes($val);
            // Regex Universal: Cocok untuk 'val', "val", atau Tanpa Kutip (konstanta)
            $content = preg_replace("/define\('$key',\s*(['\"].*?['\"]|.*?)\);/", "define('$key', '$valEscaped');", $content);
        }
        
        // Khusus SCHOOL_NAME, kita buat dia merujuk ke APP_FULL_NAME (tanpa kutip)
        $content = preg_replace("/define\('SCHOOL_NAME',\s*(['\"].*?['\"]|.*?)\);/", "define('SCHOOL_NAME', APP_FULL_NAME);", $content);
        
        file_put_contents($koneksiPath, $content);
    }

    // 3. TIMPA config/gdrive-auth.json
    $gdriveFile = __DIR__ . '/../config/gdrive-auth.json';
    if(!empty($new_gdrive_client) && !empty($new_gdrive_secret)) {
        $gdriveData = [];
        if(file_exists($gdriveFile)){
            $gdriveData = json_decode(file_get_contents($gdriveFile), true) ?: [];
        }
        $gdriveData['web'] = [
            "client_id" => $new_gdrive_client,
            "project_id" => $gdriveData['web']['project_id'] ?? "e-arsip-app",
            "auth_uri" => "https://accounts.google.com/o/oauth2/auth",
            "token_uri" => "https://oauth2.googleapis.com/token",
            "auth_provider_x509_cert_url" => "https://www.googleapis.com/oauth2/v1/certs",
            "client_secret" => $new_gdrive_secret
        ];
        file_put_contents($gdriveFile, json_encode($gdriveData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    setFlash('success', 'Konfigurasi Sistem Dasar telah diperbarui secara permanen!');
    if(ob_get_length()) ob_clean();
    header('Location: ' . BASE_URL . '/admin/pengaturan');
    exit;
}

// ---------------------------------------------------------
// PERSIAPAN NILAI AWAL FORM (CURRENT DATA)
// ---------------------------------------------------------
$current_app_name = defined('APP_FULL_NAME') ? APP_FULL_NAME : '';
$current_city = defined('APP_CITY') ? APP_CITY : '';

$current_bot_token = defined('TELEGRAM_BOT_TOKEN') ? TELEGRAM_BOT_TOKEN : '';
$current_chat_id = defined('TELEGRAM_CHAT_ID') ? TELEGRAM_CHAT_ID : '';
$current_telegram_backup = defined('TELEGRAM_BACKUP_DB') ? TELEGRAM_BACKUP_DB : 'N';
$current_telegram_period = defined('TELEGRAM_BACKUP_PERIOD') ? TELEGRAM_BACKUP_PERIOD : 'manual';
$current_telegram_time = defined('TELEGRAM_BACKUP_TIME') ? TELEGRAM_BACKUP_TIME : '00:00';

// Baca current G-Drive
$gdriveFile = __DIR__ . '/../config/gdrive-auth.json';
$current_gdrive_client = '';
$current_gdrive_secret = '';
if(file_exists($gdriveFile)){
    $parsed_gdrive = json_decode(file_get_contents($gdriveFile), true);
    if(isset($parsed_gdrive['web'])) {
        $current_gdrive_client = $parsed_gdrive['web']['client_id'] ?? '';
        $current_gdrive_secret = $parsed_gdrive['web']['client_secret'] ?? '';
    }
}

require_once __DIR__ . '/templates/header.php';
?>

<!-- Header -->
<div class="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
    <div>
        <h1 class="text-3xl font-black tracking-tight text-emerald-800 dark:text-emerald-400">Pengaturan Sistem</h1>
        <p class="mt-2 text-emerald-600 dark:text-emerald-400/60 font-medium">Ubah konfigurasi fundamental identitas dan API eksternal.</p>
    </div>
</div>

<div class="max-w-4xl">
    <!-- Peringatan Akses -->
    <div class="mb-6 rounded-2xl border-l-4 border-amber-500 bg-amber-500/10 p-4 shadow-sm">
        <div class="flex items-center gap-3">
            <i class="fas fa-exclamation-triangle text-amber-500 text-xl"></i>
            <p class="text-sm font-medium text-amber-700 dark:text-amber-500">
                <strong class="font-bold">Informasi Penting:</strong> Sistem akan menyimpan perubahan secara otomatis ke dalam kerangka inti aplikasi. Pastikan Anda memasukkan data Telegram dan Google Drive yang benar agar koneksi tidak terputus.
            </p>
        </div>
    </div>

    <!-- MAIN FORM CARD -->
    <div class="rounded-[2.5rem] border border-gray-200 dark:border-white/10 bg-white/80 dark:bg-black/40 backdrop-blur-2xl p-8 shadow-2xl xl:p-12 relative overflow-hidden">
        
        <!-- Ornamen Latar -->
        <div class="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-emerald-500/10 blur-3xl"></div>
        <div class="pointer-events-none absolute -bottom-32 -left-32 h-80 w-80 rounded-full bg-teal-500/10 blur-3xl"></div>

        <form action="" method="POST" class="space-y-10 relative z-10">
            
            <!-- 1. IDENTITAS MADRASAH SECTION -->
            <div class="rounded-3xl bg-gray-50/50 dark:bg-white/5 p-6 border border-gray-200 dark:border-white/10">
                <h3 class="flex items-center gap-3 border-b border-gray-200 dark:border-white/10 pb-4 text-xl font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
                    <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-600 dark:text-emerald-300"><i class="fas fa-school"></i></div>
                    Identitas Inti Madrasah
                </h3>
                <div class="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-gray-700 dark:text-emerald-300">Nama Madrasah / Sekolah *</label>
                        <input type="text" name="app_full_name" value="<?= htmlspecialchars($current_app_name) ?>" required
                            class="w-full rounded-2xl border border-gray-300 dark:border-white/10 bg-white dark:bg-black/20 py-4 px-6 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-white dark:focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 shadow-inner">
                    </div>
                    <div>
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-gray-700 dark:text-emerald-300">Kota / Kabupaten (Tanda Tangan)</label>
                        <input type="text" name="app_city" value="<?= htmlspecialchars($current_city) ?>" placeholder="Contoh: Kotagajah"
                            class="w-full rounded-2xl border border-gray-300 dark:border-white/10 bg-white dark:bg-black/20 py-4 px-6 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-white dark:focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 shadow-inner">
                    </div>
                </div>
            </div>

            <!-- 2. NOTIFIKASI TELEGRAM SECTION -->
            <div class="rounded-3xl bg-gray-50/50 dark:bg-white/5 p-6 border border-gray-200 dark:border-white/10">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 dark:border-white/10 pb-4 gap-3">
                    <h3 class="flex items-center gap-3 text-xl font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
                        <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-500/20 text-blue-600 dark:text-blue-300"><i class="fab fa-telegram"></i></div>
                        Notifikasi Bot Telegram <span class="text-xs font-semibold text-gray-500 dark:text-white/40 normal-case tracking-normal ml-2 rounded-full border border-gray-300 dark:border-white/10 px-3 py-1 bg-white dark:bg-black/20">(Opsional)</span>
                    </h3>
                    
                    <?php if(!empty($current_bot_token)): ?>
                    <div class="flex items-center gap-2 px-4 py-2 bg-emerald-100 dark:bg-emerald-500/20 rounded-xl border border-emerald-200 dark:border-emerald-500/30">
                        <i class="fas fa-check-circle text-emerald-600 dark:text-emerald-400"></i>
                        <span class="text-sm font-bold text-emerald-700 dark:text-emerald-300">Terdeteksi Aktif</span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-gray-700 dark:text-emerald-300">Bot Token API</label>
                        <input type="text" name="telegram_bot_token" value="<?= htmlspecialchars($current_bot_token) ?>" placeholder="Contoh: 1234567890:ABCdefGhIJklMNOpq..."
                            class="w-full rounded-2xl border border-gray-300 dark:border-white/10 bg-white dark:bg-black/20 py-4 px-6 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-white dark:focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 shadow-inner">
                    </div>
                    <div>
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-gray-700 dark:text-emerald-300">Chat ID Akun Anda</label>
                        <input type="text" name="telegram_chat_id" value="<?= htmlspecialchars($current_chat_id) ?>" placeholder="Contoh: 1920833101"
                            class="w-full rounded-2xl border border-gray-300 dark:border-white/10 bg-white dark:bg-black/20 py-4 px-6 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-white dark:focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 shadow-inner">
                    </div>
                    
                    <div class="md:col-span-2 pt-2 border-t border-gray-200 dark:border-white/10 mt-2">
                        <label class="flex items-center gap-3 cursor-pointer group mb-4 mt-2">
                            <div class="relative">
                                <input type="checkbox" name="telegram_backup" value="Y" <?= $current_telegram_backup === 'Y' ? 'checked' : '' ?> class="sr-only peer" onchange="document.getElementById('autoBackupOptions').style.opacity = this.checked ? '1' : '0.4'; document.getElementById('autoBackupOptions').style.pointerEvents = this.checked ? 'auto' : 'none';">
                                <div class="w-14 h-7 bg-gray-300 dark:bg-white/10 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-emerald-500/30 rounded-full peer peer-checked:after:translate-x-7 peer-checked:after:border-white after:content-[''] after:absolute after:top-1 after:left-1 after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-emerald-500"></div>
                            </div>
                            <div>
                                <span class="text-sm font-bold uppercase tracking-wider text-gray-700 dark:text-emerald-300">Kirim Database ke Telegram saat Backup</span>
                                <p class="text-xs text-gray-500 dark:text-white/40 font-medium">Jika diaktifkan, file *.sql hasil pencadangan (*backup*) akan otomatis dikirim (di-forward) ke Telegram Anda via Bot.</p>
                            </div>
                        </label>

                        <div id="autoBackupOptions" class="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 transition-all" style="<?= $current_telegram_backup === 'Y' ? '' : 'opacity:0.4; pointer-events:none;' ?>">
                            <div>
                                <label class="mb-2 block text-xs font-bold uppercase tracking-wider text-gray-700 dark:text-emerald-300">Otomasi / Periode Kirim</label>
                                <select name="telegram_backup_period" class="w-full rounded-xl border border-gray-300 dark:border-white/10 bg-white dark:bg-black/20 py-3 px-4 text-gray-900 dark:text-white focus:border-emerald-500/50 focus:ring-2 focus:ring-emerald-500/10 outline-none">
                                    <option value="manual" <?= $current_telegram_period === 'manual' ? 'selected' : '' ?>>Manual (Saat Tombol Unduh Diklik)</option>
                                    <option value="daily" <?= $current_telegram_period === 'daily' ? 'selected' : '' ?>>Tiap Hari (Otomatis)</option>
                                    <option value="weekly" <?= $current_telegram_period === 'weekly' ? 'selected' : '' ?>>Tiap Minggu (Otomatis)</option>
                                    <option value="monthly" <?= $current_telegram_period === 'monthly' ? 'selected' : '' ?>>Tiap Bulan (Otomatis)</option>
                                </select>
                            </div>
                            <div>
                                <label class="mb-2 block text-xs font-bold uppercase tracking-wider text-gray-700 dark:text-emerald-300">Jam Eksekusi Otomatis</label>
                                <input type="time" name="telegram_backup_time" value="<?= htmlspecialchars($current_telegram_time) ?>" class="w-full rounded-xl border border-gray-300 dark:border-white/10 bg-white dark:bg-black/20 py-3 px-4 text-gray-900 dark:text-white focus:border-emerald-500/50 focus:ring-2 focus:ring-emerald-500/10 outline-none">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 3. GOOGLE DRIVE API SECTION -->
            <div class="rounded-3xl bg-gray-50/50 dark:bg-white/5 p-6 border border-gray-200 dark:border-white/10">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-200 dark:border-white/10 pb-4 gap-3">
                    <h3 class="flex items-center gap-3 text-xl font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400">
                        <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-orange-500/20 text-orange-600 dark:text-orange-300"><i class="fab fa-google-drive"></i></div>
                        Kredensial Google Drive API <span class="text-xs font-semibold text-gray-500 dark:text-white/40 normal-case tracking-normal ml-2 rounded-full border border-gray-300 dark:border-white/10 px-3 py-1 bg-white dark:bg-black/20">(Opsional)</span>
                    </h3>
                    
                    <?php if(!empty($current_gdrive_client)): ?>
                    <div class="flex items-center gap-2 px-4 py-2 bg-emerald-100 dark:bg-emerald-500/20 rounded-xl border border-emerald-200 dark:border-emerald-500/30">
                        <i class="fas fa-check-circle text-emerald-600 dark:text-emerald-400"></i>
                        <span class="text-sm font-bold text-emerald-700 dark:text-emerald-300">Kredensial Terdeteksi</span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-gray-700 dark:text-emerald-300">OAUTH2 Client ID</label>
                        <input type="text" name="gdrive_client_id" value="<?= htmlspecialchars($current_gdrive_client) ?>" placeholder="Masukkan Client ID"
                            class="w-full rounded-2xl border border-gray-300 dark:border-white/10 bg-white dark:bg-black/20 py-4 px-6 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-white dark:focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 shadow-inner">
                    </div>
                    <div>
                        <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-gray-700 dark:text-emerald-300">OAUTH2 Client Secret</label>
                        <input type="text" name="gdrive_client_secret" value="<?= htmlspecialchars($current_gdrive_secret) ?>" placeholder="Masukkan Client Secret"
                            class="w-full rounded-2xl border border-gray-300 dark:border-white/10 bg-white dark:bg-black/20 py-4 px-6 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-white dark:focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 shadow-inner">
                    </div>
                </div>
            </div>
            
            <!-- 4. PENCADANGAN DATABASE -->
            <div class="rounded-3xl bg-gray-50/50 dark:bg-white/5 p-6 border border-gray-200 dark:border-white/10">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <h3 class="flex items-center gap-3 text-xl font-black uppercase tracking-widest text-emerald-600 dark:text-emerald-400 m-0">
                        <div class="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-500/20 text-purple-600 dark:text-purple-300"><i class="fas fa-database"></i></div>
                        Pencadangan Database
                    </h3>
                    <a href="<?= BASE_URL ?>/admin/backup_db" class="flex items-center justify-center gap-2 rounded-xl bg-purple-600 hover:bg-purple-500 px-6 py-3 font-bold text-white shadow-lg transition-all active:scale-95 no-underline block max-w-xs text-sm ml-auto">
                        <i class="fas fa-download"></i> Unduh Database (.sql)
                    </a>
                </div>
                <p class="mt-4 text-sm text-gray-600 dark:text-white/60 font-medium">Mengunduh seluruh isi dan cadangan database sistem ini. Jika pengiriman Telegram di atas diaktifkan, hasil unduhan (.sql) ini juga akan diakumulasikan ke aplikasi chat Anda sebagai arsip terpisah.</p>
            </div>

            <!-- TOMBOL SIMPAN -->
            <div class="pt-6">
                <button type="submit" id="submitBtn"
                    class="flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 py-5 font-black uppercase tracking-widest text-white transition-all hover:shadow-2xl hover:shadow-emerald-500/40 active:scale-95">
                    <i class="fas fa-save text-xl"></i> SIMPAN SEMUA PERUBAHAN
                </button>
            </div>
            
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/templates/footer.php'; ?>
