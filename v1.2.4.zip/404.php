<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 — Halaman Tidak Ditemukan | E-Arsip Digital</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0a0f1a;
            overflow: hidden;
            position: relative;
        }

        /* Animated Background */
        .bg-grid {
            position: fixed; inset: 0; z-index: 0;
            background-image:
                linear-gradient(rgba(16,185,129,0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(16,185,129,0.03) 1px, transparent 1px);
            background-size: 60px 60px;
            animation: gridPulse 8s ease-in-out infinite;
        }
        @keyframes gridPulse {
            0%, 100% { opacity: 0.5; }
            50% { opacity: 1; }
        }

        .bg-glow {
            position: fixed; z-index: 0;
            width: 600px; height: 600px;
            border-radius: 50%;
            filter: blur(180px);
            opacity: 0.15;
            animation: floatGlow 12s ease-in-out infinite;
        }
        .bg-glow-1 { background: #10b981; top: -200px; left: -100px; }
        .bg-glow-2 { background: #f59e0b; bottom: -200px; right: -100px; animation-delay: 4s; }
        @keyframes floatGlow {
            0%, 100% { transform: translate(0, 0) scale(1); }
            50% { transform: translate(30px, 20px) scale(1.15); }
        }

        /* Main Card */
        .card-404 {
            position: relative; z-index: 10;
            text-align: center;
            padding: 60px 40px;
            max-width: 520px;
            width: 90%;
        }

        .error-code {
            font-size: clamp(100px, 20vw, 160px);
            font-weight: 900;
            line-height: 1;
            background: linear-gradient(135deg, #10b981, #059669, #34d399);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            text-shadow: none;
            position: relative;
            animation: breathe 4s ease-in-out infinite;
        }
        @keyframes breathe {
            0%, 100% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.03); opacity: 0.85; }
        }

        .error-title {
            font-size: 1.5rem;
            font-weight: 900;
            color: #fff;
            margin-top: 10px;
            letter-spacing: -0.5px;
        }

        .error-desc {
            color: rgba(255,255,255,0.4);
            font-size: 0.875rem;
            margin-top: 12px;
            line-height: 1.7;
            font-weight: 500;
        }

        .divider {
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, transparent, #10b981, transparent);
            margin: 30px auto;
            border-radius: 99px;
        }

        /* Buttons */
        .btn-group {
            display: flex;
            gap: 12px;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 30px;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 14px 28px;
            border-radius: 16px;
            font-weight: 900;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 2px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            border: none;
        }
        .btn-primary {
            background: linear-gradient(135deg, #10b981, #059669);
            color: #fff;
            box-shadow: 0 8px 30px rgba(16,185,129,0.3);
        }
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 40px rgba(16,185,129,0.5);
        }
        .btn-ghost {
            background: rgba(255,255,255,0.05);
            color: rgba(255,255,255,0.5);
            border: 1px solid rgba(255,255,255,0.1);
        }
        .btn-ghost:hover {
            background: rgba(255,255,255,0.1);
            color: #fff;
            transform: translateY(-3px);
        }

        .brand {
            margin-top: 50px;
            font-size: 0.6rem;
            font-weight: 900;
            text-transform: uppercase;
            letter-spacing: 4px;
            color: rgba(255,255,255,0.1);
        }
        .brand i { color: rgba(16,185,129,0.3); margin-right: 6px; }

        /* Floating Particles */
        .particle {
            position: fixed;
            width: 4px; height: 4px;
            background: #10b981;
            border-radius: 50%;
            opacity: 0;
            z-index: 1;
            animation: particleFloat 6s ease-in-out infinite;
        }
        @keyframes particleFloat {
            0% { opacity: 0; transform: translateY(100vh) scale(0); }
            50% { opacity: 0.6; }
            100% { opacity: 0; transform: translateY(-100vh) scale(1); }
        }
    </style>
</head>
<body>
    <!-- Background Effects -->
    <div class="bg-grid"></div>
    <div class="bg-glow bg-glow-1"></div>
    <div class="bg-glow bg-glow-2"></div>

    <!-- Floating Particles -->
    <div class="particle" style="left:10%;animation-delay:0s;animation-duration:5s;"></div>
    <div class="particle" style="left:25%;animation-delay:1s;animation-duration:7s;"></div>
    <div class="particle" style="left:40%;animation-delay:2s;animation-duration:6s;"></div>
    <div class="particle" style="left:55%;animation-delay:0.5s;animation-duration:8s;"></div>
    <div class="particle" style="left:70%;animation-delay:3s;animation-duration:5.5s;"></div>
    <div class="particle" style="left:85%;animation-delay:1.5s;animation-duration:7s;"></div>
    <div class="particle" style="left:95%;animation-delay:2.5s;animation-duration:6.5s;"></div>

    <!-- Main Content -->
    <div class="card-404">
        <div class="error-code">404</div>
        <h1 class="error-title">Halaman Tidak Ditemukan</h1>
        <p class="error-desc">
            Alamat yang Anda tuju tidak tersedia atau telah dipindahkan.<br>
            Periksa kembali URL atau kembali ke halaman utama.
        </p>

        <div class="divider"></div>

        <div class="btn-group">
            <a href="/" class="btn btn-primary">
                <i class="fas fa-home"></i> Beranda
            </a>
            <a href="javascript:history.back()" class="btn btn-ghost">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>

        <div class="brand">
            <i class="fas fa-archive"></i> E-Arsip Digital — MTs Ma'arif 02 Kotagajah
        </div>
    </div>
</body>
</html>
