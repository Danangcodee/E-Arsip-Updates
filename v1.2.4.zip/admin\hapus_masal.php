<?php
/**
 * ============================================================
 * BULK DELETE — Hapus Masal Arsip
 * ============================================================
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
require_once __DIR__ . '/../config/gdrive.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ids']) && is_array($_POST['ids'])) {
    $ids = $_POST['ids'];
    $countSuccess = 0;
    $countFailed = 0;

    foreach ($ids as $id) {
        $id = (int) $id;

        // 1. Ambil GDrive ID dari database
        $stmt = $koneksi->prepare("SELECT gdrive_file_id, nama_arsip FROM arsip WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $arsip = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($arsip) {
            // 2. Hapus dari Google Drive
            $deletedFromCloud = true;
            if (!empty($arsip['gdrive_file_id'])) {
                try {
                    $deletedFromCloud = deleteFromGDrive($arsip['gdrive_file_id']);
                } catch (Exception $e) {
                    // Jika gagal hapus cloud, tetap lanjut hapus lokal agar tidak nyangkut
                    $deletedFromCloud = true; 
                }
            }

            // 3. Hapus dari Database jika berhasil (atau dianggap berhasil)
            if ($deletedFromCloud) {
                $del = $koneksi->prepare("DELETE FROM arsip WHERE id = ?");
                $del->bind_param('i', $id);
                if ($del->execute()) {
                    $countSuccess++;
                } else {
                    $countFailed++;
                }
                $del->close();
            } else {
                $countFailed++;
            }
        }
    }

    if ($countSuccess > 0) {
        // Catat Log
        logActivity('Hapus Masal', "Berhasil menghapus $countSuccess arsip secara masal.");
        
        setFlash('success', "$countSuccess arsip berhasil dihapus secara masal! ✅");
    }
    
    if ($countFailed > 0) {
        setFlash('error', "$countFailed arsip gagal dihapus.");
    }

} else {
    setFlash('warning', 'Tidak ada arsip yang dipilih untuk dihapus.');
}

header('Location: ' . BASE_URL . '/admin/arsip');
exit;

