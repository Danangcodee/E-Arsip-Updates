# 📂 E-Arsip Digital - MTs Ma'arif 02 Kotagajah

Sistem Informasi Digital (SIP) untuk pengelolaan arsip madrasah yang modern, aman, dan terintegrasi dengan Cloud Storage. Dikembangkan oleh **Tumenggung Danang Triharto**.

## 🚀 Fitur Unggulan v1.0.0
* **☁️ Google Drive API (OAuth2):** Penyimpanan file otomatis ke awan, aman dari risiko kehilangan data lokal.
* **🤖 Real-time Telegram Bot:** Notifikasi instan ke grup/personal setiap ada aktivitas upload atau perubahan data.
* **📂 Smart Folder Mapping:** Pembuatan folder di Google Drive secara otomatis berdasarkan kategori dokumen.
* **📊 Dynamic Dashboard:** Ringkasan data arsip, penggunaan penyimpanan, dan sapaan dinamis sesuai waktu.
* **🛰️ Remote Update System:** Notifikasi pembaruan aplikasi secara real-time yang terintegrasi dengan GitHub JSON.
* **📄 PDF Report Generator:** Cetak laporan arsip lengkap dengan Kop Madrasah resmi secara otomatis.

## 🛠️ Tech Stack
- **Backend:** PHP 8.x (Native/Clean Code)
- **Frontend:** HTML5, CSS3, JavaScript (Dashboard Responsive)
- **Database:** MySQL/MariaDB
- **Integrasi:** Google Drive API, Telegram Bot API, GitHub Versioning

---
## 👨‍💻 Developer
**Tumenggung Danang Triharto** *Sistem Informasi Digital (SIP) Developer*

*"Digitalisasi Madrasah, Transformasi Masa Depan."*
