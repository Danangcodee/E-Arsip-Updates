<?php
/**
 * ============================================================
 * CETAK LAPORAN ARSIP — E-Arsip Digital MTs Ma'arif 02 Kotagajah
 * ============================================================
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
requireLogin();

$search   = trim($_GET['q'] ?? '');
$kategori = (int) ($_GET['kategori'] ?? 0);
$periode  = $_GET['periode'] ?? 'semua';
$tglMulai = $_GET['tgl_mulai'] ?? '';
$tglAkhir = $_GET['tgl_akhir'] ?? '';

$where  = "WHERE 1=1";
$params = [];
$types  = '';

// Filter Pencarian
if ($search) {
    $where .= " AND (a.nama_arsip LIKE ? OR a.nomor_surat LIKE ? OR a.deskripsi LIKE ?)";
    $searchParam = "%$search%";
    $params[] = &$searchParam; $params[] = &$searchParam; $params[] = &$searchParam;
    $types .= 'sss';
}

// Filter Kategori
if ($kategori > 0) {
    $where .= " AND a.kategori_id = ?";
    $params[] = &$kategori;
    $types .= 'i';
}

// Filter Periode
$labelPeriode = 'Semua Waktu';
switch ($periode) {
    case 'hari':
        $where .= " AND DATE(a.created_at) = CURDATE()";
        $labelPeriode = 'Hari Ini (' . date('d/m/Y') . ')';
        break;
    case '7hari':
        $where .= " AND a.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
        $labelPeriode = '7 Hari Terakhir';
        break;
    case 'bulan':
        $where .= " AND MONTH(a.created_at) = MONTH(CURDATE()) AND YEAR(a.created_at) = YEAR(CURDATE())";
        $labelPeriode = 'Bulan ' . date('F Y');
        break;
    case 'tahun':
        $where .= " AND YEAR(a.created_at) = YEAR(CURDATE())";
        $labelPeriode = 'Tahun ' . date('Y');
        break;
    case 'custom':
        if ($tglMulai && $tglAkhir) {
            $where .= " AND DATE(a.created_at) BETWEEN ? AND ?";
            $params[] = &$tglMulai;
            $params[] = &$tglAkhir;
            $types .= 'ss';
            $labelPeriode = date('d/m/Y', strtotime($tglMulai)) . ' s/d ' . date('d/m/Y', strtotime($tglAkhir));
        }
        break;
}

$query = "SELECT a.*, k.nama_kategori FROM arsip a LEFT JOIN kategori k ON a.kategori_id = k.id $where ORDER BY a.created_at DESC";
$stmtData = $koneksi->prepare($query);
if ($types) $stmtData->bind_param($types, ...$params);
$stmtData->execute();
$arsipList = $stmtData->get_result();
$stmtData->close();

// Total ukuran file
$totalUkuran = 0;
$dataRows = [];
while ($r = $arsipList->fetch_assoc()) {
    $dataRows[] = $r;
    $totalUkuran += $r['ukuran_file'];
}

// Nama Kategori untuk judul
$judulKategori = "Semua Kategori";
if ($kategori > 0) {
    $cat = $koneksi->query("SELECT nama_kategori FROM kategori WHERE id = $kategori")->fetch_assoc();
    $judulKategori = $cat['nama_kategori'] ?? "Kategori ID: $kategori";
}

$bulanIndo = [
    1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];
$tglCetak = date('j') . ' ' . $bulanIndo[(int)date('n')] . ' ' . date('Y');
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Arsip - <?= $judulKategori ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Times New Roman', Times, serif; color: #000; line-height: 1.4; padding: 15px 30px; font-size: 12px; }

        /* KOP SURAT */
        .kop {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-bottom: 6px;
            margin-bottom: 3px;
        }
        .kop-logo { width: 170px; height: auto; flex-shrink: 0; margin-left: -5px; }
        .kop-text { flex: 1; text-align: right; font-family: 'Times New Roman', Times, serif; }
        .kop-text .lembaga {
            font-size: 16px;
            font-weight: bold;
            color: #1a5c1a;
            margin: 0;
            letter-spacing: 0.5px;
        }
        .kop-text .sekolah {
            font-size: 22px;
            font-weight: 900;
            color: #1a5c1a;
            margin: 0;
            letter-spacing: 1px;
        }
        .kop-text .akreditasi {
            font-size: 13px;
            font-weight: bold;
            color: #1a5c1a;
            margin: 0 0 5px 0;
            letter-spacing: 1px;
        }
        .kop-text .alamat {
            font-size: 12px;
            color: #1a5c1a;
            margin: 0 0 8px 0;
        }
        .kop-kontak {
            font-size: 11px;
            color: #000;
            line-height: 1.5;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 2px;
        }
        .kontak-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .kontak-icon {
            width: 14px;
            height: 14px;
            display: inline-block;
        }
        .kop-line1 {
            border: none;
            border-top: 3px solid #1a5c1a;
            margin-bottom: 2px;
        }
        .kop-line2 {
            border: none;
            border-top: 1px solid #1a5c1a;
            margin-bottom: 20px;
        }

        /* JUDUL */
        .title {
            text-align: center;
            margin-bottom: 20px;
            margin-top: 15px;
        }
        .title h3 {
            font-size: 18px;
            text-decoration: underline;
            text-transform: uppercase;
            margin-bottom: 6px;
            letter-spacing: 1px;
        }
        .title p { font-size: 13px; margin: 3px 0; }

        /* TABEL */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px; }
        table th, table td { border: 1px solid #111; padding: 7px 8px; vertical-align: middle; }
        table th {
            background-color: #e8f5e9;
            text-transform: uppercase;
            font-size: 11px;
            font-weight: bold;
            letter-spacing: 0.5px;
            text-align: center;
        }
        table td { font-size: 12px; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }

        /* FOOTER */
        .summary {
            margin-top: 20px;
            font-size: 13px;
        }
        .summary table { font-size: 13px; }
        .summary td { border: none; padding: 3px 6px; vertical-align: top; }

        .ttd {
            margin-top: 30px;
            float: right;
            text-align: center;
            width: 280px;
            font-size: 13px;
        }
        .ttd .tempat { margin-bottom: 3px; font-weight: bold; }

        /* NO PRINT */
        .no-print-bar {
            background: #1a5c1a;
            color: #fff;
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-family: 'Segoe UI', sans-serif;
            font-size: 13px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
        }
        .no-print-bar button {
            background: #fff;
            color: #1a5c1a;
            border: none;
            padding: 8px 20px;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            font-size: 12px;
        }
        .no-print-bar button:hover { background: #c8e6c9; }
        .no-print-bar button.btn-secondary {
            background: rgba(255,255,255,0.2);
            color: #fff;
        }

        @media print {
            .no-print, .no-print-bar { display: none !important; }
            body { padding: 0; }
            @page { size: A4 landscape; margin: 1.2cm; }
        }
    </style>
</head>
<body>
    <!-- Toolbar Cetak -->
    <div class="no-print-bar no-print">
        <span>📄 <strong>Laporan Rekapitulasi Arsip Digital</strong> — <?= $labelPeriode ?></span>
        <div>
            <button onclick="window.print()">🖨️ Cetak / Save PDF</button>
            <button class="btn-secondary" onclick="location.href='arsip'">← Kembali</button>
        </div>
    </div>

    <!-- JUDUL LAPORAN -->
    <div class="title">
        <h3>Laporan Rekapitulasi Arsip Digital</h3>
        <p>Kategori: <strong><?= $judulKategori ?></strong></p>
        <p>Periode: <strong><?= $labelPeriode ?></strong></p>
    </div>

    <!-- TABEL DATA -->
    <table>
        <thead>
            <tr>
                <th style="width:25px">No</th>
                <th style="width:25%">Nama Arsip / Judul</th>
                <th>Kategori</th>
                <th>Nomor Surat</th>
                <th>Tanggal Arsip</th>
                <th>Tanggal Upload</th>
                <th>Ukuran</th>
                <th style="width:20%">Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            if (count($dataRows) > 0):
                foreach ($dataRows as $row): 
            ?>
            <tr>
                <td class="text-center"><?= $no++ ?></td>
                <td>
                    <strong><?= sanitize($row['nama_arsip']) ?></strong><br>
                    <small style="color:#666"><?= sanitize($row['nama_file']) ?></small>
                </td>
                <td class="text-center"><?= sanitize($row['nama_kategori']) ?></td>
                <td class="text-center"><?= sanitize($row['nomor_surat'] ?: '-') ?></td>
                <td class="text-center"><?= date('d/m/Y', strtotime($row['tanggal_arsip'])) ?></td>
                <td class="text-center"><?= date('d/m/Y', strtotime($row['created_at'])) ?></td>
                <td class="text-right"><?= formatFileSize($row['ukuran_file']) ?></td>
                <td><?= sanitize($row['deskripsi'] ?: '-') ?></td>
            </tr>
            <?php endforeach; else: ?>
            <tr><td colspan="8" style="text-align:center; padding:20px;">Belum ada data arsip yang tersedia untuk periode ini.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- RINGKASAN -->
    <div class="summary">
        <table style="width: auto; margin-top: 10px;">
            <tr>
                <td><strong>Total Dokumen</strong></td>
                <td>: <?= count($dataRows) ?> arsip</td>
            </tr>
            <tr>
                <td><strong>Total Ukuran</strong></td>
                <td>: <?= formatFileSize($totalUkuran) ?></td>
            </tr>
            <tr>
                <td><strong>Dicetak oleh</strong></td>
                <td>: <?= sanitize($_SESSION['nama_lengkap'] ?? $_SESSION['user_nama'] ?? 'Admin') ?></td>
            </tr>
        </table>
    </div>

    <!-- TTD -->
    <div class="ttd">
        <div class="tempat"><?= APP_FULL_NAME ?></div>
        <div style="margin-bottom: 60px;">
            <?= defined('APP_CITY') ? APP_CITY . ', ' : '' ?><?= $tglCetak ?>
        </div>
        <div>
            <strong style="text-decoration: underline;"><?= sanitize($_SESSION['nama_lengkap'] ?? $_SESSION['user_nama'] ?? 'Administrator') ?></strong><br>
            <small><i>Petugas Arsip Digital</i></small>
        </div>
    </div>

    <div style="clear:both"></div>
</body>
</html>

