<?php
/**
 * Logout handler
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';

session_destroy();
header('Location: ' . BASE_URL . '/auth/login');
exit;

