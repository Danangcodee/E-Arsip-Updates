<?php
/**
 * ============================================================
 * KELOLA KATEGORI — E-Arsip Digital MTs Ma'arif 02 Kotagajah
 * ============================================================
 */
if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
requireLogin();

// ============================================================
// PROSES TAMBAH KATEGORI
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'tambah') {
        $nama = trim($_POST['nama_kategori'] ?? '');
        $desk = trim($_POST['deskripsi'] ?? '');
        
        if (!empty($nama)) {
            $stmt = $koneksi->prepare("INSERT INTO kategori (nama_kategori, deskripsi) VALUES (?, ?)");
            $stmt->bind_param('ss', $nama, $desk);
            
            if ($stmt->execute()) {
                // Catat Log
                logActivity('Tambah Kategori', "Menambah kategori baru: \"$nama\"");
                
                setFlash('success', "Kategori \"$nama\" berhasil ditambahkan. ✅");
            } else {
                setFlash('error', 'Gagal menambah kategori.');
            }
            $stmt->close();
        }
        header('Location: ' . BASE_URL . '/admin/kategori');
        exit;
    }
}

// ============================================================
// PROSES HAPUS KATEGORI
// ============================================================
if (isset($_GET['hapus']) && is_numeric($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    $cek = $koneksi->query("SELECT COUNT(*) as c FROM arsip WHERE kategori_id = $id")->fetch_assoc()['c'];
    
    if ($cek > 0) {
        setFlash('error', "Kategori tidak bisa dihapus karena masih digunakan oleh $cek arsip.");
    } else {
        $stmt = $koneksi->prepare("SELECT nama_kategori FROM kategori WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $namaKat = $stmt->get_result()->fetch_assoc()['nama_kategori'] ?? 'Unknown';
        $stmt->close();

        $stmt = $koneksi->prepare("DELETE FROM kategori WHERE id = ?");
        $stmt->bind_param('i', $id);
        if ($stmt->execute()) {
            // Catat Log
            logActivity('Hapus Kategori', "Menghapus kategori: \"$namaKat\"");
            
            setFlash('success', 'Kategori berhasil dihapus. 🗑️');
        } else {
            setFlash('error', 'Gagal menghapus kategori.');
        }
        $stmt->close();
    }
    header('Location: ' . BASE_URL . '/admin/kategori');
    exit;
}

$pageTitle    = 'Kelola Kategori';
$pageSubtitle = 'Atur kategori untuk arsip digital';
$activePage   = 'kategori';

require_once __DIR__ . '/templates/header.php';

$kategoriList = $koneksi->query("
    SELECT k.*, COUNT(a.id) as jumlah_arsip 
    FROM kategori k 
    LEFT JOIN arsip a ON k.id = a.kategori_id 
    GROUP BY k.id 
    ORDER BY k.nama_kategori ASC
");
?>

<div class="p-4 sm:p-6 lg:p-8 space-y-8">
    <div class="mb-4">
        <h1 class="text-3xl font-extrabold tracking-tight text-white">Kelola <span class="text-emerald-400">Kategori</span></h1>
        <p class="mt-2 text-sm text-emerald-400/70">Klasifikasikan dokumen Anda agar lebih terorganisir.</p>
    </div>

    <!-- Form Tambah Kategori (Premium Glass) -->
    <div class="max-w-xl rounded-[2rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl">
        <div class="rounded-[1.75rem] bg-gradient-to-br from-white/10 to-transparent p-6">
            <h2 class="mb-5 text-xl font-black uppercase tracking-widest text-emerald-300">➕ Tambah Kategori</h2>
            <form method="POST" action="" class="space-y-4">
                <input type="hidden" name="action" value="tambah">
                <div class="space-y-4">
                    <input type="text" name="nama_kategori" required
                        class="w-full rounded-xl border border-white/10 bg-black/20 py-3 px-5 text-white placeholder-white/30 transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
                        placeholder="Nama Kategori Baru...">
                    
                    <input type="text" name="deskripsi"
                        class="w-full rounded-xl border border-white/10 bg-black/20 py-3 px-5 text-white placeholder-white/30 transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
                        placeholder="Deskripsi Singkat (Opsional)">
                </div>
                <button type="submit" class="mt-2 w-full rounded-xl bg-emerald-600 py-4 font-black uppercase tracking-widest text-white transition-all hover:bg-emerald-500 hover:shadow-lg active:scale-95">
                    Simpan Kategori
                </button>
            </form>
        </div>
    </div>

    <!-- Daftar Kategori -->
    <div class="rounded-[2.5rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl">
        <div class="rounded-[2.25rem] bg-gradient-to-br from-white/10 to-transparent overflow-hidden">
            <div class="p-8">
                <h2 class="text-xl font-black uppercase tracking-widest text-emerald-300">🏷️ Daftar Kategori Tersedia</h2>
            </div>
            
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead class="bg-black/20 text-emerald-400 uppercase text-xs font-black tracking-widest">
                        <tr>
                            <th class="px-8 py-5">#</th>
                            <th class="px-8 py-5">Kategori</th>
                            <th class="px-8 py-5">Deskripsi</th>
                            <th class="px-8 py-5 text-center">Dokumen</th>
                            <th class="px-8 py-5 text-right">Tindakan</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-white/5">
                        <?php 
                        $no = 1;
                        while ($kat = $kategoriList->fetch_assoc()): 
                        ?>
                        <tr class="hover:bg-white/5 transition-colors group">
                            <td class="px-8 py-6 text-white/50"><?= $no++ ?></td>
                            <td class="px-8 py-6">
                                <span class="rounded-lg bg-emerald-500/10 px-4 py-2 text-sm font-bold text-emerald-300 border border-emerald-500/20">
                                    <?= sanitize($kat['nama_kategori']) ?>
                                </span>
                            </td>
                            <td class="px-8 py-6 text-white/60 italic"><?= sanitize($kat['deskripsi'] ?: 'Tanpa Deskripsi') ?></td>
                            <td class="px-8 py-6 text-center">
                                <span class="bg-black/40 px-3 py-1 rounded-full text-sm font-black text-white"><?= $kat['jumlah_arsip'] ?></span>
                            </td>
                            <td class="px-8 py-6 text-right">
                                <?php if ($kat['jumlah_arsip'] == 0): ?>
                                <a href="?hapus=<?= $kat['id'] ?>" class="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500 hover:text-white transition-all shadow-lg" 
                                   onclick="return confirm('Hapus kategori ini secara permanen?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                                <?php else: ?>
                                <div class="flex items-center justify-end gap-2">
                                    <span class="text-[10px] font-black text-white/5 uppercase tracking-widest leading-none">Terkunci</span>
                                    <div class="relative inline-block">
                                        <button type="button" 
                                                onclick="togglePop(this, '<?= $kat['nama_kategori'] ?>', <?= $kat['jumlah_arsip'] ?>)"
                                                class="text-emerald-500/30 hover:text-emerald-500 transition-all cursor-pointer p-1">
                                            <i class="fas fa-info-circle text-xs"></i>
                                        </button>
                                        <!-- Mini Popover (Hidden by default) -->
                                        <div class="pop-content hidden absolute bottom-full right-0 mb-3 w-56 rounded-2xl border border-emerald-500/30 bg-emerald-950/80 p-4 shadow-2xl backdrop-blur-xl z-[100] animate-in fade-in slide-in-from-bottom-2 duration-200">
                                            <div class="space-y-2">
                                                <p class="text-[10px] font-black text-emerald-300 uppercase italic tracking-widest border-b border-emerald-500/20 pb-2 flex items-center gap-2">
                                                    <i class="fas fa-lock text-[8px]"></i> Alasan Terkunci
                                                </p>
                                                <p class="text-[10px] leading-relaxed text-white/80 font-medium">
                                                    Kategori <b class="text-white"><?= $kat['nama_kategori'] ?></b> tidak bisa dihapus karena masih menampung <b class="text-emerald-400"><?= $kat['jumlah_arsip'] ?> dokumen</b>.
                                                </p>
                                            </div>
                                            <!-- Arrow -->
                                            <div class="absolute top-full right-3 w-3 h-3 bg-emerald-950/80 border-r border-b border-emerald-500/30 rotate-45 -translate-y-[6.5px]"></div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script>
function togglePop(btn) {
    // Tutup semua popover lain dulu
    document.querySelectorAll('.pop-content').forEach(p => {
        if(p !== btn.nextElementSibling) p.classList.add('hidden');
    });
    
    // Toggle popover yang diklik
    const pop = btn.nextElementSibling;
    pop.classList.toggle('hidden');
}

// Tutup jika klik di luar
window.addEventListener('click', (e) => {
    if (!e.target.closest('.relative')) {
        document.querySelectorAll('.pop-content').forEach(p => p.classList.add('hidden'));
    }
});
</script>

<?php require_once __DIR__ . '/templates/footer.php'; ?>

