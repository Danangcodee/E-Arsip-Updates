<?php
// Pengaturan Versi Aplikasi
$app_version = '1.1.0';
$update_tersedia = false; // Ubah ke true untuk memunculkan kotak notifikasi update
?>
