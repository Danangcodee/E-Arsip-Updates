<?php
/**
 * Redirect ke Dashboard
 */
if (!file_exists(__DIR__ . '/config/koneksi.php')) { header('Location: install/'); exit; }
require_once __DIR__ . '/config/koneksi.php';
header('Location: ' . BASE_URL . '/admin/dashboard');
exit;

