<?php
/**
 * ============================================================
 * EDIT ARSIP — E-Arsip Digital
 * ============================================================
 */
$pageTitle    = "Edit Arsip";
$pageSubtitle = "Perbarui informasi dokumen";
$activePage   = "arsip";

if (!file_exists(__DIR__ . '/../config/koneksi.php')) { header('Location: ../install/'); exit; }
require_once __DIR__ . '/../config/koneksi.php';
requireLogin();
require_once __DIR__ . '/templates/header.php';

// Ambil ID Arsip
$id = $_GET['id'] ?? null;
if (!$id) {
    echo "<script>location.href='arsip';</script>";
    exit();
}

// Ambil data arsip lama
$stmt = $koneksi->prepare("SELECT * FROM arsip WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$arsip = $stmt->get_result()->fetch_assoc();

if (!$arsip) {
    echo "<script>alert('Arsip tidak ditemukan!'); location.href='arsip';</script>";
    exit();
}

// Proses Update
$error = '';
$success = '';

if (isset($_POST['update'])) {
    $nama      = mysqli_real_escape_string($koneksi, $_POST['nama_arsip']);
    $kategori  = (int)$_POST['kategori_id'];
    $nomor     = mysqli_real_escape_string($koneksi, $_POST['nomor_surat']);
    $tanggal   = $_POST['tanggal_arsip'];
    $deskripsi = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);

    if (empty($nama) || empty($kategori)) {
        $error = "Nama arsip dan kategori wajib diisi!";
    } else {
        $sql = "UPDATE arsip SET 
                kategori_id = ?, 
                nama_arsip = ?, 
                nomor_surat = ?, 
                tanggal_arsip = ?, 
                deskripsi = ? 
                WHERE id = ?";
        
        $updateStmt = $koneksi->prepare($sql);
        $updateStmt->bind_param("issssi", $kategori, $nama, $nomor, $tanggal, $deskripsi, $id);
        
        if ($updateStmt->execute()) {
            $success = "Informasi arsip berhasil diperbarui!";
            // Refresh data
            $stmt->execute();
            $arsip = $stmt->get_result()->fetch_assoc();
        } else {
            $error = "Gagal memperbarui database: " . $koneksi->error;
        }
    }
}
?>

<div class="p-4 sm:p-6 lg:p-8">
    <!-- Header Page -->
    <div class="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h1 class="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
                Edit <span class="bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">Arsip</span>
            </h1>
            <p class="mt-2 text-sm font-medium text-emerald-400/80">
                <i class="fas fa-edit mr-1"></i> Perbarui informasi dokumen: #<?php echo $id; ?>
            </p>
        </div>
        <div>
            <a href="arsip" class="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-6 py-3 text-sm font-bold text-white backdrop-blur-md transition-all hover:bg-white/10 hover:shadow-lg active:scale-95">
                <i class="fas fa-arrow-left"></i> Kembali ke Daftar
            </a>
        </div>
    </div>

    <!-- Main Content Card -->
    <div class="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <!-- Form Section -->
        <div class="lg:col-span-2">
            <div class="overflow-hidden rounded-[2.5rem] border border-white/10 bg-white/5 p-1 shadow-2xl backdrop-blur-2xl">
                <div class="rounded-[2.25rem] bg-gradient-to-br from-white/10 to-transparent p-6 sm:p-10">
                    
                    <?php if($error): ?>
                    <div class="mb-8 animate-shake rounded-2xl border border-red-500/30 bg-red-500/10 p-5 text-red-400 backdrop-blur-xl">
                        <div class="flex items-center gap-3">
                            <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-500/20 text-red-500">
                                <i class="fas fa-times"></i>
                            </div>
                            <p class="text-sm font-semibold"><?php echo $error; ?></p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if($success): ?>
                    <div class="mb-8 animate-bounce-short rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-5 text-emerald-400 backdrop-blur-xl">
                        <div class="flex items-center gap-3">
                            <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-500">
                                <i class="fas fa-check"></i>
                            </div>
                            <p class="text-sm font-semibold"><?php echo $success; ?></p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <form action="" method="POST" class="space-y-8">
                        <div class="grid grid-cols-1 gap-8 md:grid-cols-2">
                            <!-- Nama Arsip -->
                            <div class="md:col-span-2">
                                <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Nama Arsip <span class="text-red-500">*</span></label>
                                <div class="relative group">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-4 text-emerald-500/50 group-focus-within:text-emerald-400">
                                        <i class="fas fa-file-signature"></i>
                                    </div>
                                    <input type="text" name="nama_arsip" required
                                        value="<?php echo htmlspecialchars($arsip['nama_arsip']); ?>"
                                        class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 pl-12 pr-4 text-white placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
                                        placeholder="Masukkan nama arsip...">
                                </div>
                            </div>

                            <!-- Kategori -->
                            <div>
                                <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Kategori <span class="text-red-500">*</span></label>
                                <div class="relative group">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-4 text-emerald-500/50">
                                        <i class="fas fa-tags"></i>
                                    </div>
                                    <select name="kategori_id" required
                                        class="w-full appearance-none rounded-2xl border border-white/10 bg-black/20 py-4 pl-12 pr-4 text-white transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10">
                                        <?php
                                        $cats = $koneksi->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");
                                        while($c = $cats->fetch_assoc()):
                                        ?>
                                        <option value="<?php echo $c['id']; ?>" <?php echo ($c['id'] == $arsip['kategori_id']) ? 'selected' : ''; ?> class="bg-gray-900 text-white">
                                            <?php echo htmlspecialchars($c['nama_kategori']); ?>
                                        </option>
                                        <?php endwhile; ?>
                                    </select>
                                    <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-4 text-emerald-500/50">
                                        <i class="fas fa-chevron-down text-xs"></i>
                                    </div>
                                </div>
                            </div>

                            <!-- Nomor Surat -->
                            <div>
                                <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Nomor Surat</label>
                                <div class="relative group">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-4 text-emerald-500/50">
                                        <i class="fas fa-hashtag"></i>
                                    </div>
                                    <input type="text" name="nomor_surat"
                                        value="<?php echo htmlspecialchars($arsip['nomor_surat']); ?>"
                                        class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 pl-12 pr-4 text-white placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
                                        placeholder="No. Surat (opsional)...">
                                </div>
                            </div>

                            <!-- Tanggal -->
                            <div>
                                <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Tanggal Arsip <span class="text-red-500">*</span></label>
                                <div class="relative group">
                                    <div class="absolute inset-y-0 left-0 flex items-center pl-4 text-emerald-500/50">
                                        <i class="fas fa-calendar-alt"></i>
                                    </div>
                                    <input type="date" name="tanggal_arsip" required
                                        value="<?php echo $arsip['tanggal_arsip']; ?>"
                                        class="w-full rounded-2xl border border-white/10 bg-black/20 py-4 pl-12 pr-4 text-white transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10">
                                </div>
                            </div>

                            <!-- Deskripsi -->
                            <div class="md:col-span-2">
                                <label class="mb-3 block text-sm font-bold uppercase tracking-wider text-emerald-300">Deskripsi / Catatan</label>
                                <textarea name="deskripsi" rows="4"
                                    class="w-full rounded-2xl border border-white/10 bg-black/20 p-4 text-white placeholder-white/20 transition-all focus:border-emerald-500/50 focus:bg-black/40 focus:outline-none focus:ring-4 focus:ring-emerald-500/10"
                                    placeholder="Tambahkan keterangan tambahan..."><?php echo htmlspecialchars($arsip['deskripsi']); ?></textarea>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="pt-6">
                            <button type="submit" name="update"
                                class="group relative flex w-full items-center justify-center gap-3 overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 py-5 font-black uppercase tracking-widest text-white shadow-2xl transition-all hover:shadow-emerald-500/40 active:scale-95">
                                <div class="absolute inset-0 bg-white/20 opacity-0 transition-opacity group-hover:opacity-100"></div>
                                <i class="fas fa-save text-xl transition-transform group-hover:rotate-12"></i>
                                Simpan Perubahan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Sidebar Info Section -->
        <div class="space-y-8">
            <!-- File Info Card -->
            <div class="overflow-hidden rounded-[2.5rem] border border-white/10 bg-white/5 p-1 backdrop-blur-2xl">
                <div class="rounded-[2.25rem] bg-gradient-to-br from-emerald-500/10 to-transparent p-6 sm:p-8">
                    <h3 class="mb-6 flex items-center gap-3 text-lg font-bold text-white uppercase tracking-tight">
                        <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/20 text-emerald-400">
                            <i class="fas fa-file-alt text-sm"></i>
                        </span>
                        Detail File
                    </h3>
                    
                    <div class="space-y-6">
                        <div class="rounded-2xl bg-black/20 p-5 border border-white/5 transition-all hover:border-emerald-500/30">
                            <p class="text-[10px] font-black uppercase tracking-widest text-emerald-500/60 mb-1">Nama File Original</p>
                            <p class="text-sm font-bold text-white truncate"><?php echo htmlspecialchars($arsip['nama_file']); ?></p>
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div class="rounded-2xl bg-black/20 p-5 border border-white/5">
                                <p class="text-[10px] font-black uppercase tracking-widest text-emerald-500/60 mb-1">Ukuran</p>
                                <p class="font-bold text-white"><?php echo formatFileSize($arsip['ukuran_file']); ?></p>
                            </div>
                            <div class="rounded-2xl bg-black/20 p-5 border border-white/5">
                                <p class="text-[10px] font-black uppercase tracking-widest text-emerald-500/60 mb-1">Tipe</p>
                                <p class="font-bold text-white uppercase"><?php echo str_replace('application/', '', $arsip['tipe_file']); ?></p>
                            </div>
                        </div>

                        <div class="pt-4">
                            <a href="<?php echo $arsip['gdrive_view_link']; ?>" target="_blank"
                                class="flex w-full items-center justify-center gap-3 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 py-4 text-sm font-black uppercase tracking-widest text-emerald-400 transition-all hover:bg-emerald-500 hover:text-white">
                                <i class="fas fa-external-link-alt"></i>
                                Lihat di G-Drive
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Warning Card -->
            <div class="rounded-[2.5rem] bg-amber-500/10 p-8 border border-amber-500/20">
                <div class="flex items-start gap-4">
                    <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-amber-500/20 text-amber-500">
                        <i class="fas fa-info-circle text-xl"></i>
                    </div>
                    <div>
                        <h4 class="font-bold text-amber-500">PENTING!</h4>
                        <p class="mt-2 text-sm leading-relaxed text-amber-100/70">
                            Fitur ini hanya untuk mengubah **informasi data**. Jika ingin mengganti file fisik, silakan hapus arsip ini dan upload ulang file baru.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
    }
    .animate-shake { animation: shake 0.5s ease-in-out; }
    .animate-bounce-short { animation: bounce 1s ease-in-out infinite; }
</style>

<?php require_once __DIR__ . '/templates/footer.php'; ?>

